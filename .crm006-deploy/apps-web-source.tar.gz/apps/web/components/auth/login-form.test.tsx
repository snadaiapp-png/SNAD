// @vitest-environment jsdom

import "@testing-library/jest-dom/vitest";

import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { LoginForm } from "./login-form";
import { I18nProvider } from "@/lib/i18n/I18nProvider";

const onLoginMock = vi.fn();

vi.mock("next/link", () => ({
  default: ({
    href,
    children,
    ...props
  }: React.AnchorHTMLAttributes<HTMLAnchorElement>) => (
    <a href={String(href)} {...props}>
      {children}
    </a>
  ),
}));

function renderLoginForm(overrides: Partial<React.ComponentProps<typeof LoginForm>> = {}) {
  return render(
    <I18nProvider>
      <LoginForm
        onLogin={onLoginMock}
        authenticating={false}
        error={null}
        {...overrides}
      />
    </I18nProvider>,
  );
}

describe("LoginForm", () => {
  beforeEach(() => {
    onLoginMock.mockReset();
  });

  afterEach(() => {
    cleanup();
  });

  it("renders email and password fields", () => {
    renderLoginForm();
    expect(screen.getByPlaceholderText("name@company.com")).toBeInTheDocument();
    expect(screen.getByPlaceholderText("••••••••")).toBeInTheDocument();
  });

  it("does not render a tenant UUID field", () => {
    renderLoginForm();
    expect(screen.queryByText(/tenant/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/مستأجر/i)).not.toBeInTheDocument();
  });

  it("validates required email", async () => {
    const user = userEvent.setup();
    renderLoginForm();
    await user.click(screen.getByRole("button", { name: "تسجيل الدخول" }));
    expect(screen.getByText("البريد الإلكتروني مطلوب.")).toBeInTheDocument();
    expect(onLoginMock).not.toHaveBeenCalled();
  });

  it("validates required password", async () => {
    const user = userEvent.setup();
    renderLoginForm();
    await user.type(screen.getByPlaceholderText("name@company.com"), "test@example.com");
    await user.click(screen.getByRole("button", { name: "تسجيل الدخول" }));
    expect(screen.getByText("كلمة المرور مطلوبة.")).toBeInTheDocument();
    expect(onLoginMock).not.toHaveBeenCalled();
  });

  it("normalizes email to trimmed lowercase before calling login", async () => {
    const user = userEvent.setup();
    renderLoginForm();
    await user.type(screen.getByPlaceholderText("name@company.com"), "  Test@Example.COM  ");
    await user.type(screen.getByPlaceholderText("••••••••"), "Password123!");
    await user.click(screen.getByRole("button", { name: "تسجيل الدخول" }));
    expect(onLoginMock).toHaveBeenCalledWith("test@example.com", "Password123!");
  });

  it("calls onLogin with the correct values", async () => {
    const user = userEvent.setup();
    renderLoginForm();
    await user.type(screen.getByPlaceholderText("name@company.com"), "user@snad.app");
    await user.type(screen.getByPlaceholderText("••••••••"), "SecretPass1!");
    await user.click(screen.getByRole("button", { name: "تسجيل الدخول" }));
    expect(onLoginMock).toHaveBeenCalledTimes(1);
    expect(onLoginMock).toHaveBeenCalledWith("user@snad.app", "SecretPass1!");
  });

  it("disables the submit button while authenticating", () => {
    renderLoginForm({ authenticating: true });
    const button = screen.getByRole("button", { name: "جارٍ تسجيل الدخول…" });
    expect(button).toBeDisabled();
  });

  it("toggles password visibility", async () => {
    const user = userEvent.setup();
    renderLoginForm();
    const passwordInput = screen.getByPlaceholderText("••••••••");
    expect(passwordInput).toHaveAttribute("type", "password");
    const toggle = screen.getByLabelText("إظهار كلمة المرور");
    await user.click(toggle);
    expect(passwordInput).toHaveAttribute("type", "text");
    const hideToggle = screen.getByLabelText("إخفاء كلمة المرور");
    await user.click(hideToggle);
    expect(passwordInput).toHaveAttribute("type", "password");
  });

  it("displays user-facing error safely", () => {
    renderLoginForm({
      error: { title: "غير مصرح", message: "البريد الإلكتروني أو كلمة المرور غير صحيحة.", kind: "validation" },
    });
    expect(screen.getByRole("alert")).toHaveTextContent("غير مصرح");
    expect(screen.getByRole("alert")).toHaveTextContent("البريد الإلكتروني أو كلمة المرور غير صحيحة.");
  });

  it("does not display raw error or stack trace", () => {
    renderLoginForm({
      error: { title: "خطأ في الخادم", message: "حدث خطأ داخلي في الخادم.", kind: "server" },
    });
    const alert = screen.getByRole("alert");
    expect(alert.textContent).not.toMatch(/stack|trace|at \//i);
    expect(alert.textContent).not.toMatch(/https?:\/\//);
  });

  it("shows help panel and renders a forgot-password link with icon", async () => {
    const user = userEvent.setup();
    renderLoginForm();
    await user.click(screen.getByRole("button", { name: "تحتاج مساعدة في الدخول؟" }));
    // Help panel appears
    expect(screen.getByText(/تواصل مع مسؤول النظام/)).toBeInTheDocument();
    // The forgot-password link is rendered with the canonical /auth/* route
    const forgotLink = screen.getByRole("link", { name: /نسيت كلمة المرور؟/ });
    expect(forgotLink).toHaveAttribute("href", "/auth/forgot-password");
  });

  it("renders the forgot-password link above the submit button (directly below password field)", () => {
    renderLoginForm();
    const forgotLink = screen.getByRole("link", { name: /نسيت كلمة المرور؟/ });
    const submitButton = screen.getByRole("button", { name: /تسجيل الدخول/ });
    // Verify visual order: link comes before submit button in DOM
    expect(forgotLink.compareDocumentPosition(submitButton)).toBe(
      Node.DOCUMENT_POSITION_FOLLOWING,
    );
  });

  it("provides an accessible aria-label on the forgot-password link", () => {
    renderLoginForm();
    const forgotLink = screen.getByRole("link", { name: /نسيت كلمة المرور؟/ });
    expect(forgotLink).toHaveAttribute(
      "aria-label",
      "نسيت كلمة المرور؟",
    );
  });
});
