# APR-2R Test Matrix R3 — عزل المستأجرين لجدول tenant_subscriptions
## SNAD-APR2R-TEST-MATRIX-R3-2026-10-28 — الوثيقة الرئيسية (المراجعة التصحيحية المغلقة النطاق)

| الحقل | القيمة |
|---|---|
| المعرّف الكلي | `SNAD-APR2R-TEST-MATRIX-R3-2026-10-28` |
| المراجعة | **R3** — تصحيحية مغلقة النطاق تعالج الملاحظات R1–R5 على R2؛ تعتمد على `SNAD-APR2R-TEST-MATRIX-R2-2026-10-28` (بأرشيفه `SNAD-APR2R-TEST-MATRIX-R2-2026-10-28.zip`، SHA-256 = `a1369da44ce929be9686285905e8ef710078749400980a36072e8e26456a66e0`) **دون أي تعديل** |
| المستودع | `/home/z/my-project/SNAD` @ `c43a70a5603bdb5a63a193f66de5e83b29ecc454` (مُتحقق منه قراءةً فقط بتاريخ 2026-10-28) |
| الفرع | `review/unified-control-plane-revision-c-reconstructed` |
| طبيعة المعرّفات | **مشتقة من المصدر (DERIVED)** — بادئة `R2R-` كما في R2 والأصل |
| طبيعة المهمة | **مراجعة تصميم واختبار للملفات فقط** — صفر اتصال بقاعدة، صفر SQL تنفيذي، صفر اختبارات، صفر تعديل مخطط/RLS/أدوار |
| قرار هذه الوثيقة | **READY FOR REVIEW** (تصميم مصحّح) — **ليست موافقة تنفيذ**؛ كل الخانات الاثنتي عشرة اليوم = `NOT_RUN` والتنفيذ = `BLOCKED_PREREQUISITE` (لا بيئة معزولة مثبتة + لا اعتماد صريح) |
| سجل التصحيحات | `04_CHANGES_R3.md` — لكل تصحيح: القسم، المشكلة السابقة، التعديل، السبب، دليل الاكتمال، الحالة |
| تقرير التحقق | `05_VALIDATION_REPORT.md` — التحقق الجنائي من المدخلات والمخرجات والبصمات |

---

## §01 النطاق والمنهجية ومفردات الحالة

**الهدف**: مصفوفة اختبارات تحقق لافتراضات عزل المستأجرين حول `tenant_subscriptions` وجداولها المباشرة، مشتقة بالكامل من مصادر المستودع عند HEAD المعتمد. R3 تعالج الملاحظات الخمس R1–R5 الواردة في مراجعة R2: (R1) بروتوكول تجهيز بيانات المستأجرين وسياق RLS؛ (R2) عزل محاولات B2 والتمييز الجنائي بين أخطاء PostgreSQL؛ (R3) التحقق الكتالوغي المحدد المخطط للسياسات؛ (R4) فصل هوية الفاعل عن المستأجر المستهدف وجرد مسارات Executive الفعلي؛ (R5) خطط تنظيف مستقلة مثبتة من آثار الكتابة الفعلية لكل مسار.

**قواعد مشتقة تلتزمها كل خانة اختبار**:
1. كل معرّف اختبار مشتق ويحمل بادئة `R2R-`؛ معرفات R3 تُضاف كلاحقات بروتوكولية (مثل محاولات B2: `R2R-B2/T1…T6`) دون تغيير هويات الاختبارات الاثني عشر.
2. لا يُعامل `app.tenant_id` وحده كإثبات عزل — يُختبر سلوكه فعليًا لكل جدول (وقد يكون بلا أثر إطلاقًا على الجدول الأم — R2R-B4).
3. غياب RLS على الجدول الأم يُسجَّل **كحقيقة مستمدة من المصدر**؛ **غياب RLS بمفرده ليس إثباتًا لثغرة قابلة للاستغلال** — حدود التخويل على مستوى التطبيق تُقيَّم استقلالًا (خانات الطبقة A)؛ لا يُقدَّم أي ادعاء استغلال دون تنفيذ مستقبلي يثبت مسار وصول غير مصرح.
4. معايير النجاح/الفشل/الحجب صريحة لكل خانة؛ **لا يُسجَّل PASS دون سجل تنفيذ فعلي** (سجلات جلسة/لقطات/استجابات HTTP محفوظة).
5. صفر `ALTER ROLE`/`CREATE ROLE`/`GRANT`/`REVOKE`/DDL/تعديل سياسات ضمن هذا التكتيك — خصائص الدور تُتحقق **قراءةً فقط** من `pg_roles`؛ أي مخالفة تُسجَّل `BLOCKED` ولا تُصلح.
6. أي تصحيح يستلزم تغيير كود مصدر أو مخطط أو صلاحيات يُسجَّل **عنصرًا خارج النطاق** ولا يُنفَّذ.

**مفردات الحالة (ملزمة لكل خانة)**:

| الحالة | الدلالة |
|---|---|
| `PASS` | النتيجة الفعلية مطابقة للمتوقع **مع سجل تنفيذ فعلي محفوظ** |
| `FAIL` | نتيجة فعلية مخالفة للمتوقع مع دليل — تستلزم إعادة اشتقاق/معالجة قبل أي اعتماد |
| `NOT_RUN` | الاختبار مصمم ولم يُنفَّذ — **هذه حالة كل الخانات اليوم** |
| `BLOCKED_PREREQUISITE` | شرط مسبق غير متوفر (بيئة معزولة/دور/كتالوج/تجهيز بيانات آمن) — لا حكم سلوكي |
| `BLOCKED_CLEANUP_UNPROVEN` | تعذّر إثبات اكتمال تنظيف آثار الاختبار — يُمنع تشغيل الاختبار |
| `SOURCE_VERIFICATION_REQUIRED` | نقطة تحتاج تحققًا من مصدر لم يكن متاحًا/لم يُقرأ كاملًا — لا تخمين |
| `EXPECTED_SQLSTATE_REQUIRES_RUNTIME_CONFIRMATION` | SQLSTATE المتوقع مشتق من تعريف السياسة/القيود في المصدر، لكن تأكيده السلوكي يتطلب التنفيذ الفعلي وتسجيل القيمة الفعلية |

**الحالة الحالية**: جميع الاختبارات `NOT_RUN`؛ طبقة B بأكملها وطبقات A/C التنفيذية `BLOCKED_PREREQUISITE` عند اليوم لغياب البيئة المعزولة المثبتة (§6.1). هذه الوثيقة تصميم جاهز للمراجعة البشرية المستقلة فقط.

---

## §02 الطبقات الثلاث وسلسلة الحراس وجرد المسارات الفعلي (R4 — مُعاد التحقق منه 2026-10-28)

| الطبقة | الرمز | مصدر العزل المتوقع | طبيعة الاختبار |
|---|---|---|---|
| 1 — تخويل التطبيق وملكية الموارد | `R2R-A*` | فلترة `tenant_id = ?` في كود التطبيق + سلسلة بوابتين + هوية fail-closed | اختبارات مسار تطبيقي (API/Service) |
| 2 — عزل صفوف PostgreSQL (RLS) | `R2R-B*` | ENABLE/FORCE RLS + سياسة `tenant_isolation` بـ USING/WITH CHECK على GUC | اختبارات SQL مباشرة بدور `sanad` |
| 3 — الوصول المقصود من لوحة التحكم | `R2R-C*` | بوابات قدرات EXECUTIVE_VIEW/EXECUTIVE_MANAGE — الوصول عبر المستأجرين **مقصود بالتصميم** | اختبار الحاجز = قدرة + مستأجر لوحة التحكم، لا "أي صف يُرى" |

**سلسلة الحراس (مثبتة من الكود، مُعيد التحقق)**: كل نقاط لوحة التحكم تمرّ بطبقتين متتاليتين:
1. `@RequireCapability("…")` — فحص القدرة عبر سلسلة التخويل (العقد في `ControlPlaneAccessService` L22–31 عقد الهوية، L36–52).
2. `accessGuard.require(authentication)` — `ControlPlaneAccessGuard` L25–47: يطابق `tenant_id` المستخرج من `authentication.getDetails()` مع مستأجر لوحة التحكم المهيّأ (`sanad.control-plane.tenant-id`، L21) ويفشل غلقًا في كل الفروع: تكوين غائب (L26–28)، لا مصادقة (L29–31)، تفاصيل غير صالحة (L32–34)، `tenant_id` غائب (L35–38)، تالف (L39–44)، مستأجر غير مطابق (L45–47).

**جرد المسارات التنفيذية الفعلي (R4 — مُثبت من المصدر الحالي، وليس منقولاً عن R2)**:

| # | المسار | الملف | الأسطر | القدرة | الحارس |
|---|---|---|---|---|---|
| W1 | POST `/api/v1/executive/subscriptions/{id}/lifecycle/{command}` | LifecycleController.java | L65–79 | EXECUTIVE_MANAGE (L66) | L72 |
| W2 | POST `/api/v1/executive/subscriptions/{id}/change-preview` | LifecycleController.java | L105–111 | EXECUTIVE_VIEW (L106) | L111 |
| W3 | POST `/api/v1/executive/subscriptions/{id}/changes` | LifecycleController.java | L118–131 | EXECUTIVE_MANAGE (L119) | L124 |
| W4 | POST `/api/v1/executive/subscriptions/{id}/provision` | LifecycleController.java | L133–141 | EXECUTIVE_MANAGE (L134) | L138 |
| W5 | GET `/api/v1/executive/provisioning/jobs` | LifecycleController.java | L143–170 | EXECUTIVE_VIEW (L144) | L149 |
| W6 | POST `/api/v1/executive/provisioning/jobs/{jobId}/retry` | LifecycleController.java | L176–183 | EXECUTIVE_MANAGE (L177) | L181 |
| R1 | GET `/api/v1/executive/overview` | ExecutiveReadController.java | L48–51 | EXECUTIVE_VIEW (L49) | L51 |
| R2 | GET `/api/v1/executive/tenants/v2` | ExecutiveReadController.java | L55–66 | EXECUTIVE_VIEW (L56) | L66 |
| R3 | GET `/api/v1/executive/subscriptions/v2` (معامل `tenantId` اختياري L74) | ExecutiveReadController.java | L71–86 | EXECUTIVE_VIEW (L72) | L84 |
| R4 | GET `/api/v1/executive/subscriptions/{id}/detail` | ExecutiveReadController.java | L89–94 | EXECUTIVE_VIEW (L90) | L94 |
| R5 | GET `/api/v1/executive/subscriptions/{id}` | ExecutiveReadController.java | L105–110 | EXECUTIVE_VIEW (L106) | L110 |

القاعدة المشتركة: `@RequestMapping("/api/v1/executive")` — LifecycleController.java L28 وExecutiveReadController.java L27. **مقارنةً بـ R2**: أُضيف إلى الجرد W1 وW2 وR4 وR5 التي لم تكن مفهرسة صراحةً؛ هذا توسيع توثيقي لا تغيير سلوكي.

**تفريق مصادر الرفض (R4 — إلزامي في تسجيل النتائج)**: الرفض وحده ليس إثباتًا لاختبار عزل صحيح. لكل استجابة رفض يُسجَّل مصدره:

| المصطلح | المصدر في الكود | الدليل المطلوب عند التنفيذ |
|---|---|---|
| رفض مصادقة | 401 من سلسلة الفلترة قبل أي حارس | سجل الطلب بلا رمز/رمز تالف |
| رفض قدرة | `@RequireCapability` (aspect التخويل) | 403 + سجل يذكر القدرة الناقصة |
| رفض بوابة لوحة التحكم | `ControlPlaneAccessGuard` L26–47 | 403 + سجل يطابق فرع الإغلاق (رسائل L27/L30/L33/L37/L43/L46) |
| رفض ملكية مورد | لا يوجد حارس ملكية على مسارات C — استهداف أي اشتراك **مقصود** لحامل القدرة | التحقق من غياب فحص ملكية إضافي = حقيقة تصميم، لا FAIL |

**لا يُفترض أن كل وصول متعدد المستأجرين ثغرة**: الوصول عبر المستأجرين في الطبقة C مقصود ومقيّد بالقدرة + مستأجر لوحة التحكم (§05)؛ اختبارات C تثبت **دقة الحاجز** لا العزل.

---

## §03 (R1) بروتوكول تجهيز بيانات المستأجرين وسياق RLS — إلزامي لكل اختبارات B1–B5

> **مصدر الآلية الفعلي في المشروع** (مُعيد التحقق 2026-10-28): ضبط GUC داخل المعاملة يتم بـ `SELECT set_config('app.tenant_id', ?, true)` بـ `is_local=true` — بدلالات `SET LOCAL` (TenantRlsTransactionContext.java L87–91؛ التوثيق L28–30)؛ القراءة العكسية `SELECT current_setting('app.tenant_id', true)` (L98)؛ **الضبط خارج معاملة خطأ برمجي يُرفض غلقًا** (L72–74، رسالة L84–85)؛ قيم GUC تُمسح تلقائيًا عند COMMIT/ROLLBACK — آمن لإعادة استخدام اتصالات المجمّع (TenantRlsConnectionHandler.java L12–19، شروط التفعيل L23–25: `autoCommit=false` + وجود مستأجر في السياق الأمني).
> **مسارات الخدمة التي تستخدم آلية GUC فعليًا**: UsageMeteringService.java (استدعاء `applyForCurrentTransaction` عند L59 قبل كتابة `usage_events` وL110 قبل قراءة `usage_aggregates`)؛ إضافةً إلى ModuleResetService وWorkflowExternalPortalService وSubscriptionFinanceAdapter. **وحدة الاشتراكات المواجهة للمستأجر لا تستخدم GUC** — فلترتها بمعاملات مرتبطة (SubscriptionResolutionService.java L73/L93/L110).

### 3.1 هويات المستأجرين الاصطناعية

1. يُولَّد UUIDان فريدان لكل جلسة تنفيذ: `A-uuid` و`B-uuid` (نمط `r2r-<run-uuid>-A/B`)، يُسجَّلان في **سجل التنفيذ** قبل أي اتصال، ولا يُعاد استخدام UUIDs جلسة سابقة.
2. **إنشاء صفَّي المستأجرين** في جدول `tenants` بالأعمدة الإلزامية الدنيا المثبتة من المصدر (V1__create_tenants_table.sql L21–30): `id, name, subdomain, status, created_at, updated_at`؛ `subdomain` فريد عالميًا (`uk_tenants_subdomain` L29) ⇒ قيم اصطناعية مميزة لكل جلسة. أعمدة لاحقة مثل `country_code` أُضيفت قابلة للـ NULL (V16__extend_platform_identity_and_tenants.sql L5) لكن **التحقق العمودي الفعلي يُجرى وقت التنفيذ** من `information_schema.columns` (فحص P0 أدناه) — لا يُفترض من هذه الوثيقة اكتمال قائمة أعمدة أي جدول.
3. يُنشأ صف المستأجرين داخل **معاملة التجهيز** قبل أي صف تابع (كل الجداول المستهدفة لها FK نحو `tenants` بلا CASCADE من جهة الأب — V19 L58، V20260830_1 L47/L74، V20260912_4 L156 وغيرها).

### 3.2 التحقق المسبق من القيود (P0 — إلزامي قبل التجهيز)

قبل إنشاء أي بيانات اصطناعية تُنفَّذ في جلسة قراءة سلسلة P0: لكل جدول مستهدف، استخراج الأعمدة `NOT NULL` بلا DEFAULT والقيود الفريدة والFK من `information_schema.columns` و`information_schema.table_constraints`/`key_column_usage`/`referential_constraints` للمخطط `public` حصرًا، ومطابقتها مع الجدول المرجعي المثبت من المصدر (V20260912_4 لكل قمر؛ الجدول المرجعي الكامل في خانة B2). **أي تعارض بين الكتالوج الفعلي والجدول المرجعي يوقف التجهيز: `BLOCKED_PREREQUISITE`** — لا تُخمَّن الأعمدة وقت التنفيذ.

### 3.3 ضبط السياق: متى وكيف (ودلالة SET LOCAL)

1. تُضبط قيمة `app.tenant_id` **داخل كل معاملة على حدة** بـ `SELECT set_config('app.tenant_id', :uuid, true)` — أي أن **القيمة لا تنجو من معاملتها**: كل معاملة جديدة (تجهيز/اختبار A/اختبار B/بلا سياق) تعيد الضبط صراحةً أو تبقى بلا سياق عمدًا.
2. **ممنوع افتراض استمرار `SET LOCAL` خارج المعاملة التي ضُبطت فيها** — وهذا شرط تصميم لا عيب: الفحص P6 (§4.0) يثبت السلوكين معًا (القراءة داخل المعاملة + الامسح بعدها).
3. صفوف الأقمار السبعة تُنشأ **بسياق المستأجر نفسه** (`tenant_id` الصف = GUC الجلسة) لأن بند WITH CHECK في سياسة `tenant_isolation` يرفض غير المطابق (V20260912_4 L251–253 ونظيراتها حتى L293–295). **لا يُفترض نجاح إنشاء صف B أثناء سياق A** — إن اقتضى التصميم ذلك فمحاولة كتابة عاصفة تُعالج في B2/T2 فقط (كاختبار رفض، لا كوسيلة تجهيز).
4. صفوف الجدول الأم `tenant_subscriptions` بلا RLS إطلاقًا (حقيقة B4) — إنشاؤها لا يتطلب سياقًا، لكن يُستخدم سياق المستأجر التابع له الصف انضباطًا وتوحيدًا للسجل.
5. **لا تُنشأ ولا تُعدَّل أي سياسة أو RLS لتسهيل التجهيز**. إن استحال التجهيز الآمن (قيد غائب عن المرجع، FK لا يُستوفى، جدول غير موجود) ⇒ **`BLOCKED_PREREQUISITE`** مع السبب، ولا بديل تخميني.

### 3.4 فصل المراحل (إلزامي)

| المرحلة | المحتوى | المعاملة |
|---|---|---|
| مرحلة 0 | سلسلة P0 (§3.2) + P1–P6 (§4.0) + لقطات ما قبل التنفيذ (§6.1.5) | جلسات قراءة منفصلة |
| مرحلة 1 — تجهيز | إنشاء `tenants(A,B)` + الآباء المطلوبين + صفوف الاختبار لكل مستأجر بسياقه | **معاملة تجهيز مستقلة** تُثبَّت بـ COMMIT إن كان السيناريو يستلزم بقاء البيانات عبر اتصال HTTP (طبقات A/C)، أو تُلغى بـ ROLLBACK إذا اكتمل الاختبار داخلها (طبقة B) — النمط المختار يُثبت في سجل التنفيذ قبل البدء |
| مرحلة 2 — اختبار | قراءة/عزل/كتابة وفق خانة كل اختبار | معاملة مستقلة لكل اختبار (وللمحاولات في B2: **معاملة لكل محاولة**) |
| مرحلة 3 — تنظيف وإثبات | تراجع/حذف تعويضي + استعلامات إثبات صفر بقايا (§6.4) | معاملة تنظيف مستقلة |

### 3.5 مصفوفة القراءة المتقاطعة (تُسجَّل نتيجة كل استعلام حرفيًا)

لكل جدول مستهدف من الأقمار السبعة، وبعد تجهيز صفوف A وB (مرحلة 1):

| الاستعلام | السياق | النتيجة المتوقعة (مستمدة من السياسة L251–253…) |
|---|---|---|
| `SELECT tenant_id, count(*) FROM public.<satellite> GROUP BY 1` | GUC=A | صف واحد: A فقط |
| نفسه | GUC=B | صف واحد: B فقط |
| نفسه | بلا GUC | **صفر صفوف** (fail-closed) |
| `SELECT count(*) FROM public.tenant_subscriptions WHERE tenant_id = :B-uuid` | GUC=A | **عدد B الفعلي** (الجدول الأم بلا RLS — حقيقة B4، ليس فشل اختبار) |

القراءة المتقاطعة العكسية (A يرى صف B أو العكس) على الأقمار = `FAIL` فوري. رؤية صفوف B من سياق A على الجدول الأم = **النتيجة المستمدة المتوقعة** (B4) وتُسجَّل كحقيقة بيئة تُغذي قرار المعالجة — لا كادعاء استغلال (§01 قاعدة 3).

### 3.6 اختبار غياب السياق

يُنفَّذ في **جلسة/معاملة مستقلة بلا أي ضبط GUC** (وليس بعد ضبط في نفس الجلسة): عدّاد كل قمر = 0 (B3). أي صف مرئي بلا سياق = `FAIL`.

### 3.7 التراجع وإثبات عدم البقاء

بعد كل اختبار: `ROLLBACK` صريح لكل معاملة اختبار/تجهيز مؤقتة؛ ولمعاملات التجهيز المثبتة (طبقات A/C): حذف تعويضي بترتيب FK (§6.4) بمعرفات سجل التنفيذ حصرًا. الإثبات: `SELECT count(*)` لكل UUID اصطناعي في كل جدول ملموس = 0 + مطابقة لقطات الكتالوج قبل/بعد. تعذر إثبات اكتمال التنظيف ⇒ **`BLOCKED_CLEANUP_UNPROVEN`** ويتوقف التكتيك كله (§6.6).

---

## §04 الطبقة الثانية — عزل صفوف PostgreSQL (RLS) (R2R-B1…B5)

> **شرط مسبق للطبقة كلها**: بيئة PostgreSQL 16 معزولة مثبتة (نمط `pg16-local/`، منفذ 5433، ربط 127.0.0.1 فقط — غير موجودة اليوم ⇒ التنفيذ `BLOCKED_PREREQUISITE`) + دور `sanad` مطابق لعقد ci.yml L172 **تحققًا قراءةً فقط** (لا `ALTER ROLE`) + ملكية القاعدة لـ `sanad` (ci.yml L175–177). غياب أي منها = توقف الطبقة كلها.

### 4.0 شروط التحقق المسبق الموحدة — R3: استعلامات محددة المخطط (schemaname صريح في كل موضع)

تُنفَّذ في جلسة قراءة منفصلة قبل أي بيانات اصطناعية؛ **أي عدم تطابق يوقف الطبقة كلها (`BLOCKED_PREREQUISITE`)**. لا اسم جدول مجرد — كل استعلام مؤهل بـ `public.` أو `schemaname='public'`:

| # | فحص القراءة فقط | المتوقع (مستمد من المصدر) |
|---|---|---|
| P1 | `SELECT current_user, session_user;` | كلاهما `sanad` |
| P2 | `SELECT rolname, rolsuper, rolcreatedb, rolcreaterole, rolbypassrls FROM pg_roles WHERE rolname = 'sanad';` | الأعلام الأربعة = `f` (عقد ci.yml L172 — تحقق قراءة بلا تعديل) |
| P3 | `SELECT n.nspname AS schemaname, c.relname AS tablename, c.relrowsecurity, c.relforcerowsecurity, c.relowner::regrole AS owner FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'public' AND c.relname IN ('subscription_billing_provider_customers','subscription_billing_payment_attempts','subscription_billing_provider_events','subscription_billing_finance_links','subscription_billing_outbox','subscription_billing_reconciliation_runs','subscription_billing_reconciliation_items','tenant_subscriptions');` | للأقمار السبعة: `t / t / sanad` (V20260912_4 L248–295: ENABLE+FORCE)؛ للجدول الأم: `f / f / sanad` (حقيقة B4) |
| P4 | `SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check FROM pg_policies WHERE schemaname = 'public' AND tablename IN ('subscription_billing_provider_customers','subscription_billing_payment_attempts','subscription_billing_provider_events','subscription_billing_finance_links','subscription_billing_outbox','subscription_billing_reconciliation_runs','subscription_billing_reconciliation_items');` | لكل قمر سياسة واحدة `tenant_isolation`: `permissive='PERMISSIVE'`، `roles='{public}'`، `cmd='ALL'`، و`qual` و`with_check` يطابقان نصيًا النمط `tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid` (V20260912_4: L251–253, L258–260, L265–267, L272–274, L279–281, L286–288, L293–295) |
| P5 | `SELECT count(*) FROM pg_policies WHERE schemaname = 'public' AND tablename = 'tenant_subscriptions';` | `0` (لا سياسات على الجدول الأم — حقيقة R2R-B4) |
| P6 | `BEGIN; SELECT set_config('app.tenant_id', :uuid, true); SELECT current_setting('app.tenant_id', true); ROLLBACK;` ثم في معاملة جديدة: `SELECT current_setting('app.tenant_id', true);` | القيمة تُقرأ داخل معاملتها = المضبوطة؛ بعد ROLLBACK/في معاملة جديدة = NULL أو قيمة فارغة — **إثبات دلالة SET LOCAL ومسحها مع نهاية المعاملة** (TenantRlsTransactionContext.java L87–91؛ TenantRlsConnectionHandler.java L14–18) |

**حدود المقارنة النصية (R3 — إلزامي)**: مطابقة `qual`/`with_check` تكون **نصيًا بعد تطبيع المسافات**، وتُسجَّل النصان (المتوقع من المصدر والفعلي من الكتالوج) في سجل التنفيذ كما هما. **تطابق النص ليس ادعاء تكافؤ دلالي**: PostgreSQL قد يطبع التعبيرات المخزنة بصياغة مطبعة (whitespace/case) — إذا اختلفت الصياغة دون اختلغ الدلالة الصريحة، تُسجَّل الملاحظة وتُوسم الخانة `SOURCE_VERIFICATION_REQUIRED` حتى يقرر المراجع البشري. وتحقق **خصائص السياسة الفعلية** (permissive/roles/cmd/qual/with_check) ملزم — **اكتفاء اسم السياسة `tenant_isolation` وحده ليس تحققًا**.

**قواعد الدور التشغيلي أثناء التنفيذ**: كل اتصال اختبار بدور `sanad` حصرًا (P1)؛ لا إنشاء أدوار إضافية (التحقق بدور ثانٍ غير مالك خارج حدود APR-2R ⇒ `BLOCKED_PREREQUISITE` pending-decision كما في B5)؛ لا `ALTER ROLE`/`CREATE ROLE`/`GRANT`/`REVOKE` إطلاقًا.

### R2R-B1 — SELECT على الأقمار السبعة تحت سياق المستأجر يُرجع صفوفه فقط

| الحقل | النص |
|---|---|
| **الهدف الأمني / الافتراض المُختبَر** | الجداول السبعة `subscription_billing_*` محمية بـ ENABLE+FORCE RLS وسياسة `tenant_isolation` FOR ALL بـ USING/WITH CHECK على GUC؛ حتى المالك `sanad` (NOBYPASSRLS) يرى صفوف سياقه فقط. **مستوى الاختبار**: قاعدة بيانات. |
| **المتطلبات السابقة** | §6.1 كاملة + سلسلة P0 (§3.2) + P1–P6 (§4.0) + بروتوكول التجهيز §3 (معاملة/مراحل + سياق كل مستأجر + مصفوفة القراءة المتقاطعة). |
| **الدور وقاعدة البيانات** | دور `sanad` على قاعدة البيانات المعزولة المعتمدة (الهوية تُثبت في سجل التنفيذ: قاعدة/مضيف/منفذ مطابقة نصيًا للبيئة المعتمدة). |
| **بيانات الاختبار الاصطناعية (R1/R3)** | وفق §3: `tenants(A,B)` ثم صف واحد لكل قمر لكل مستأجر **بسياقه** داخل معاملة التجهيز، مع الآباء المطلوبين لكل قمر: خفيفة الاعتماديات بعد `tenants` مباشرة: `provider_customers` (V20260912_4 L24)، `provider_events` (L92)، `outbox` (L156)، `reconciliation_runs` (L181)؛ المركّبة تتطلب `tenant_subscriptions` لكل مستأجر + `billing_invoices` (و`finance_invoices` لـ `finance_links` L129، وصف runs لـ `reconciliation_items` L214–216) — تُنشأ لكل مستأجر. **وضع RLS للمخطط في وقت التجهيز يثبته P3 أولًا**؛ أي انحراف كتالوغي = `BLOCKED_PREREQUISITE`. |
| **خطوات التنفيذ بالتسلسل** | (1) معاملة مستقلة: `BEGIN;` (2) `SELECT set_config('app.tenant_id','<A-uuid>',true);` (3) `SELECT tenant_id, count(*) FROM public.<satellite> GROUP BY 1;` لكل من السبعة — تسجيل الناتج حرفيًا؛ (4) `ROLLBACK;` (5) تُعاد (1–4) بسياق B؛ (6) تُعاد بجلسة بلا GUC؛ (7) مقارنة كل ناتج بمصفوفة §3.5. |
| **النتيجة المتوقعة** | سياق A: صفوف A فقط في السبعة؛ سياق B: صفوف B فقط؛ بلا سياق: صفر صفوف في السبعة. |
| **الدليل المُجمَّع** | سجل الجلسة الكامل (كل SQL + كل ناتج + طوابع اتصال) + لقطات P3/P4 قبل وبعد. |
| **PASS / FAIL / الحجب** | PASS = تطابق تام للثلاث حالات على السبعة مع سجل محفوظ. FAIL = ظهور صفوف المستأجر الآخر أو أي صف بلا سياق. `BLOCKED_PREREQUISITE` = لا بيئة/فشل P-series/تعذر تجهيز آمن. **الحالة اليوم: `NOT_RUN`.** |
| **SQLSTATE/HTTP** | لا ينطبق (اختبار قراءة بلا خطأ متوقع). |
| **التراجع والتنظيف (R5)** | معاملة واحدة تنتهي ROLLBACK — لا تنظيف خارجي؛ إثبات: COUNT=0 لكل UUID في السبعة + `tenants` + `tenant_subscriptions` + `billing_invoices` بعد ROLLBACK (§3.7). |
| **المخاطر والحدود** | جداول مركّبة قد تكتشف قيدًا غير مرصود وقت التنفيذ ⇒ `BLOCKED_PREREQUISITE` لا تخمين؛ لا يثبت هذا الاختبار سوى رؤية SELECT (الكتابة في B2). |
| **المصادر (مُعيد التحقق)** | V20260912_4 L248–295؛ FKs: L24, L53–58, L92–96, L123–129, L156, L181, L213–224؛ ci.yml L172؛ §3 آلية GUC. |

### R2R-B2 — WITH CHECK يمنع الكتابة عبر المستأجرين على الأقمار (R2/R3: محاولات معزولة تمامًا + تصنيف SQLSTATE جنائي)

**الهدف الأمني / الافتراض المُختبَر**: بند WITH CHECK في سياسة `tenant_isolation` يرفض INSERT/UPDATE لصف `tenant_id` ≠ سياق الجلسة — منع كتابة عبر المستأجرين على مستوى قاعدة البيانات. **مستوى الاختبار**: قاعدة بيانات (SQL مباشر بدور `sanad`). **الحالة اليوم: `NOT_RUN`؛ التنفيذ عند غياب الشروط = `BLOCKED_PREREQUISITE`.**

**الإطار المشترك للمحاولات (R2 — إلزامي، لا يُخترق)**:
1. **محاولة واحدة = معاملة مستقلة على اتصال مُحدد الهوية**: يُسجَّل لكل محاولة: معرف المحاولة، قاعدة البيانات/المضيف/المنفذ، الدور الفعلي (`SELECT current_user, session_user`) وخصائصه (لقطة `pg_roles` لـ sanad — قراءة فقط)، سياق المستأجر (GUC مضبوط/غير مضبوط)، العملية والجدول والأعمدة، المراجع المطلوبة، النتيجة المتوقعة، SQLSTATE المتوقع مع وسمه، SQLSTATE الفعلي المُسجَّل، طريقة التراجع وإثبات عدم البقاء.
2. **لا تُستأنف معاملة دخلت حالة الفشل بعد خطأ SQL**: عند أول خطأ ⇒ `ROLLBACK` صريح فوري ثم **معاملة/جلسة جديدة** للمحاولة التالية (في psql: `ON_ERROR_STOP=1` + إعادة `BEGIN`؛ في JDBC: `catch (SQLException)` → `connection.rollback()` → معاملة جديدة).
3. **التمييز الجنائي بين الأسباب** (لا تُخالط): `42501` = انتهاك سياسة RLS؛ `23503` = FK؛ `23502` = NOT NULL؛ `23514` = CHECK؛ `23505` = فريد. **`23503` ليس إثبات رفض RLS مطلقًا**؛ **`42501` وحده ليس إثبات عزل** إلا بعد الربط: (السياسة المقصودة على الجدول المستهدف مثبتة من P4) + (العملية من النوع الذي يفعّل WITH CHECK) + (الدور بلا BYPASSRLS من P2) + (سياق الجلسة الموثق). أي غياب أحد هذه الروابط ⇒ `EXPECTED_SQLSTATE_REQUIRES_RUNTIME_CONFIRMATION` وترقى السجل للمراجعة، لا PASS.
4. كل SQLSTATE متوقع في الجدول أدناه مشتق **من تعريف السياسة/القيود في المصدر** ووسمه إلزامي: `EXPECTED_SQLSTATE_REQUIRES_RUNTIME_CONFIRMATION` — القيمة الفعلية تُسجَّل وقت التنفيذ؛ **مخالفة القيمة الفعلية للمتوقع = `FAIL` لتصميم الاختبار** (إعادة اشتقاق، لا تعديل نتيجة).
5. الاختبارات السلبية (T3–T5) **محفوظة في المصفوفة** — لا تُحذف لتسهيل النجاح.

**الجدول المرجعي للاعتماديات (مثبت من V20260912_4 — مُعيد التحقق)**: `outbox` (L134–164): الأعمدة NOT NULL بلا DEFAULT: `tenant_id` (L136)، `event_type` (L137)، `aggregate_type` (L139)، `idempotency_key` (L141)؛ `UNIQUE (tenant_id, event_id)` (L154)، `UNIQUE (tenant_id, idempotency_key)` (L155)، `FK tenant_id → tenants(id)` بلا CASCADE (L156)، `CHECK event_type LIKE 'BILLING.%'` (L157)، `CHECK status IN (…)` (L158)، `CHECK payload_metadata ?| …` (L160–162). بقية الأقمار الستة: `provider_customers` (L13–30؛ NOT NULL: `provider`, `provider_customer_ref`؛ أب `tenants` L24)، `payment_attempts` (L34–66؛ أب `tenant_subscriptions(tenant_id,id)` L53–54 + `billing_invoices` L55–56 + `provider_customers` L57–58)، `provider_events` (L70–106؛ `UNIQUE (provider, provider_event_id)` عالمي L91)، `finance_links` (L108–132؛ `CHECK LIKE 'SCP_INVOICE:%'` L130–131؛ أب `finance_invoices` L129)، `reconciliation_runs` (L168–192؛ أب L181)، `reconciliation_items` (L194–243؛ `CHECK classification` L225–229؛ أب runs L214–216). سياسة outbox: ENABLE L276، FORCE L277، CREATE POLICY بـ USING/WITH CHECK L279–281.

**جدول المحاولات (الجدول المرجعي: `public.subscription_billing_outbox` — أخف اعتماديات)**:

| المحاولة | السياق (GUC) | العملية (أعمدة مكتملة) | شرط مرجعي مطلوب داخل المعاملة | النتيجة المتوقعة | SQLSTATE المتوقع (وسم إلزامي) | التراجع وإثبات عدم البقاء |
|---|---|---|---|---|---|---|
| `R2R-B2/T1` تحكم موجب | A | `INSERT INTO public.subscription_billing_outbox (tenant_id, event_type, aggregate_type, idempotency_key) VALUES ('<A>','BILLING.R2R.REF','TENANT_SUBSCRIPTION','r2r-t1-<run>')` | صف `tenants(A)` موجود (معاملة التجهيز) | نجاح — صف واحد مرئي بسياق A | لا خطأ متوقع | `ROLLBACK`؛ COUNT(A)=0 بعد التراجع |
| `R2R-B2/T2` كتابة عابرة | A | نفس الصيغة بقيم B: `('<B>','BILLING.R2R.XTENANT','TENANT_SUBSCRIPTION','r2r-t2-<run>')` | **صف `tenants(B)` موجود داخل المعاملة** — وإلا فالخطأ FK لا سياسة | رفض WITH CHECK (الصف B ≠ سياق A) | `42501` — `EXPECTED_SQLSTATE_REQUIRES_RUNTIME_CONFIRMATION` (التأكيد: سياسة outbox L279–281 من P4 + `rolbypassrls=f` من P2) | `ROLLBACK` فوري عند الخطأ (لا استئناف)؛ COUNT(B)=0 في outbox بعد التراجع |
| `R2R-B2/T3` تشخيص FK | A | نفس الصيغة بقيم B | **صف `tenants(B)` غير موجود عمدًا في هذه المعاملة** (معاملة جديدة لا تتضمنه) | رفض FK وليس سياسة — يثبت التمييز الجنائي | `23503` — `EXPECTED_SQLSTATE_REQUIRES_RUNTIME_CONFIRMATION`؛ **`23503` ليس إثبات RLS مطلقًا** | `ROLLBACK`؛ صفر أثر |
| `R2R-B2/T4` تشخيص NOT NULL | A | `INSERT (tenant_id, aggregate_type, idempotency_key)` — حذف `event_type` عمدًا | صف `tenants(A)` موجود | رفض NOT NULL (وليس RLS) | `23502` — `EXPECTED_SQLSTATE_REQUIRES_RUNTIME_CONFIRMATION` (L137) | `ROLLBACK`؛ صفر أثر |
| `R2R-B2/T5` تشخيص CHECK | A | `event_type = 'NOT_BILLING.R2R'` | صف `tenants(A)` موجود | رفض CHECK (وليس RLS) | `23514` — `EXPECTED_SQLSTATE_REQUIRES_RUNTIME_CONFIRMATION` (L157) | `ROLLBACK`؛ صفر أثر |
| `R2R-B2/T6` بلا سياق | بلا GUC | INSERT بقيم A (صيغة T1) | صف `tenants(A)` موجود | رفض (USING/WITH CHECK تقيّم NULL → غير TRUE) | `42501` — `EXPECTED_SQLSTATE_REQUIRES_RUNTIME_CONFIRMATION` | `ROLLBACK`؛ COUNT(A)=0 |

**خطوات التنفيذ لكل محاولة**: (1) اتصال جديد موثق الهوية + `BEGIN`؛ (2) ضبط GUC عند اللزوم (`set_config(…, true)`)؛ (3) تنفيذ INSERT؛ (4) عند الخطأ: تسجيل SQLSTATE الفعلي (`GET STACKED DIAGNOSTICS PG_EXCEPTION_CONSTRAINT_NAME` في DO-block أو `SQLException.getSQLState()`/`\errverbose` في psql) ثم `ROLLBACK` صريح؛ (5) معاملة تحقق مستقلة: COUNT لكل UUID = 0؛ (6) الانتقال للمحاولة التالية بمعاملة جديدة.
**النمط العكسي (إلزامي)**: تُعاد T1/T2 (وبدون فقدان العمومية T6) بسياق B: B مرجعيًا ينجح، A يُرفض بـ `42501` موسمًا.
**PASS**: نجاح T1 (وك نظيره العكسي) + رفض T2/T6 بـ `42501` الفعلي المطابق بعد تأكيد سلسلة الربط (سياسة+دور+سياق) + نتائج T3/T4/T5 مطابقة لتصنيفها + صفر بقايا بعد كل محاولة.
**FAIL**: نجاح أي عابر؛ أو رفض عابر بحالة غير `42501` (مثل `23503` — دليل خلل في إعداد الاختبار نفسه يُعاد تصميمه)؛ أو بقاء أي صف؛ أو `42501` بلا استيفاء سلسلة الربط (لا يُحسب عزلًا).
**`BLOCKED_PREREQUISITE`**: لا بيئة / فشل P-series / تعذر توفير صف `tenants(B)` داخل المعاملة.
**المصادر (مُعيد التحقق)**: V20260912_4 L134–164 (DDL)، L276–281 (سياسة outbox)، L248–295 (السبع)؛ §4.0 P2/P4؛ §3.3.

### R2R-B3 — الإغلاق الفاشل عند غياب GUC على الأقمار (fail-closed)

| الحقل | النص |
|---|---|
| **الهدف/الافتراض** | `current_setting('app.tenant_id', true)` عند الغياب يُرجع NULL → `NULLIF(NULL,'')` → NULL → مقارنة غير TRUE → السياسة تخفي كل الصفوف. **مستوى**: قاعدة بيانات. |
| **المتطلبات السابقة** | §6.1 + P0 + P1–P6 (P6 يثبت آلية الضبط/القراءة والمسح) + تجهيز §3 (صفوف A مرجعية في جدولين خفيفين على الأقل: `provider_customers` و`outbox`). |
| **الدور/القاعدة** | `sanad` على البيئة المعزولة؛ **جلسة مستقلة بلا أي GUC** (وفق §3.6 — لا جلسة سبق أن ضُبطت). |
| **الخطوات** | (1) جلسة جديدة: `SELECT count(*) FROM public.subscription_billing_provider_customers;` و`…public.subscription_billing_outbox;` → تسجيل؛ (2) معاملة جديدة بضبط GUC=A: نفس العدّادين → تحكم موجب N>0؛ (3) `ROLLBACK`. |
| **المتوقع** | بلا سياق: 0 في كل قمر مُجهَّز؛ بسياق A: صفوف A فقط (قراءة متقاطعة §3.5). |
| **PASS/FAIL/الحجب** | PASS = 0 بلا سياق + موجب يعمل (سجل محفوظ). FAIL = أي صف بلا سياق. `BLOCKED_PREREQUISITE` = لا بيئة/فشل P-series. **الحالة اليوم: `NOT_RUN`.** |
| **التراجع/التنظيف** | ROLLBACK؛ إثبات صفر بقايا (§3.7). |
| **المصادر** | V20260912_4 L252, L259, L266, L273, L280, L287, L294 (نمط NULLIF في السياسات السبع)؛ §3.3. |

### R2R-B4 — فحص حالة RLS للجدول الأم public.tenant_subscriptions (حقيقة مستمدة — لا ادعاء ثغرة)

| الحقل | النص |
|---|---|
| **الهدف/الافتراض المستمد** | المصادر تثبت أن `tenant_subscriptions` بلا RLS إطلاقًا (لا ENABLE، لا FORCE، لا سياسات)، وأن إزالتها قرار حوكمي مسجل (إسقاط V20260815_22). **مستوى**: قاعدة بيانات (قراءة كتالوج + SELECT داخل معاملة). النتيجة تُغذي قرار المعالجة **ولا تُقدَّم كادعاء استغلال** — حدود التخويل التطبيقي تُقيَّم استقلالًا في خانات A1/A2. |
| **المتطلبات السابقة** | §6.1 + تجهيز §3 (اشتراكان اصطناعيان A وB في `tenant_subscriptions` بمعاملة التجهيز/الاختبار — الأب `tenants` موجود؛ FK L58 بلا CASCADE). |
| **الدور/القاعدة** | `sanad` (المالك — ولا FORCE أصلًا على هذا الجدول). |
| **الخطوات (R3: محددة المخطط)** | (1) `SELECT n.nspname AS schemaname, c.relrowsecurity, c.relforcerowsecurity, c.relowner::regrole FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname='tenant_subscriptions';` (2) `SELECT schemaname, tablename, policyname FROM pg_policies WHERE schemaname='public' AND tablename='tenant_subscriptions';` (3) داخل معاملة: `BEGIN; SELECT set_config('app.tenant_id','<B>',true); SELECT DISTINCT tenant_id FROM public.tenant_subscriptions WHERE tenant_id IN ('<A>','<B>'); ROLLBACK;` |
| **المتوقع** | `f / f / 0 سياسات / مالك sanad`؛ الاستعلام يُظهر A **وB** معًا تحت أي سياق (0 عزل RLS) — **النتيجة المتوقعة هي تكرار الحقيقة الموثقة**. |
| **PASS/FAIL/الحجب** | PASS = البيئة تطابق الحقيقة المستمدة حرفيًا → الأدلة سليمة. FAIL = البيئة تعاكس المصدر (اكتشاف RLS فعلي) → إعادة اشتقاق فورية للمصفوفة. `BLOCKED_PREREQUISITE` = لا بيئة — **الحالة اليوم: `NOT_RUN`**. |
| **التراجع/التنظيف** | قراءات داخل معاملة تنتهي ROLLBACK؛ لقطات `pg_policies`/`pg_class` قبل/بعد متطابقة؛ صفر تعديل مخطط. |
| **المصادر** | V20260906_2 L25–27 (إقرار نصي)؛ V20260815_20 L25 (إحالة لـ V20260815_22)؛ غياب الملف من الشجرة + `git show 0a3e88c5b` (الإسقاط المقصود — من سجل المراجعة الأصلي)؛ P3/P5 أعلاه. |

### R2R-B5 — عقد الدور وFORCE RLS على الأقمار (قراءة فقط حصرًا)

| الحقل | النص |
|---|---|
| **الهدف/الافتراض** | `sanad` = NOSUPERUSER/NOBYPASSRLS (عقد CI — يُتحقق منه لا يُفرض)؛ FORCE RLS يخضع المالك للسياسة — لا تجاوز عبر ملكية ولا دور. **مستوى**: قاعدة بيانات (كتالوج). |
| **الخطوات (R3: محددة المخطط)** | (1) P2 (`pg_roles` لـ sanad — قراءة فقط؛ **لا `ALTER ROLE` لفرض القيم**)؛ (2) P3 محددة المخطط للأقمار السبعة؛ (3) تحكم متبادل مع B1 (SELECT بسياق A يُرجع A فقط). |
| **المتوقع** | `rolsuper=f, rolcreatedb=f, rolcreaterole=f, rolbypassrls=f`؛ الأقمار: `relrowsecurity=t, relforcerowsecurity=t`، المالك `sanad`. |
| **PASS/FAIL/الحجب** | PASS = كل قيم الكتالوج مطابقة. FAIL = `rolbypassrls=t` أو `relforcerowsecurity=f` على أي قمر ⇒ **لا يُحاول إصلاحها بتعديل دور إطلاقًا** — المعالجة قرار منفصل خارج التكتيك. **إن اقتضى التحقق إنشاء دور قراءة ثانٍ غير مالك ⇒ تغيير أدوار خارج الحدود ⇒ `BLOCKED_PREREQUISITE` pending-decision**. الحالة اليوم: **`NOT_RUN`**. |
| **التراجع/التنظيف** | قراءات كتالوج فقط؛ صفر تغيير؛ لقطات قبل/بعد. |
| **المصادر** | ci.yml L165–177 (العقد L172؛ الملكية L175–177)؛ V20260912_4 L248–295؛ §4.0 P2/P3. |

---

## §05 الطبقتان A وC — هوية الفاعل والمستأجر المستهدف (R4: سجل هوية خماسي إلزامي)

> **سجل الهوية الخماسي (R4)**: لكل سيناريو في A1–A4 وC1–C3 تُسجَّل العناصر الخمسة **عنصرًا عنصرًا مع دليل هوية كل مستأجر**: (1) المستخدم المصادق عليه (`user_id` من JWT — JwtAuthenticationFilter.java L74, L146–147)؛ (2) هوية مستأجر الفاعل (`tenant_id` من ادعاءات JWT → `authentication.details` L147)؛ (3) مستأجر لوحة التحكم المهيّأ (`sanad.control-plane.tenant-id` — ControlPlaneAccessGuard.java L21؛ **قيمته الفعلية بيئة تشغيلية** ⇒ `SOURCE_VERIFICATION_REQUIRED` عند غياب تكوين البيئة)؛ (4) المستأجر المستهدف بالعملية (يُستمد من **صف الجدول** في مسارات الكتابة — أدلة C3)؛ (5) القدرة المطلوبة (`@RequireCapability`). ثم نتائج: `ControlPlaneAccessGuard.require()` (إن مرّ به المسار)، استجابة HTTP، السجلات المقروءة/المغيَّرة.
> **تفريق الرفوض**: كل رفض يُصنَّف وفق جدول §02 (مصادقة/قدرة/بوابة لوحة/ملكية) — الرفض المجرد ليس إثبات عزل.

### R2R-A1 — دقة الحل الفعّالة للاشتراك: صف المستأجر نفسه فقط

| الحقل | النص |
|---|---|
| **الهدف/الافتراض** | المسار المواجه للمستأجر يُرجع اشتراك الطالب فقط عبر `tenant_id = ?` صريح — لأن الجدول الأم بلا RLS فهذا الفلتر **طبقة العزل الوحيدة** هنا. **مستوى**: تطبيق (API/Service). |
| **سجل الهوية (R4)** | (1) مستخدم JWT عادي؛ (2) مستأجر الفاعل = A (ثم B في السيناريو الثاني)؛ (3) مستأجر لوحة التحكم = لا ينطبق (مسار مستأجر عادي)؛ (4) المستهدف = A (يُستمد من هوية الفاعل نفسها في الخدمة)؛ (5) القدرة = لا تُشترط قدرة تنفيذية. دليل هوية: شهادات JWT منفصلة لكل مستأجر. |
| **المسار المُختبَر** | `SubscriptionResolutionService`: `FROM tenant_subscriptions WHERE tenant_id = ? AND <EFFECTIVE_PREDICATE>` (L73)؛ التاريخ L93؛ الأحدث L110 — **معاملات مرتبطة، لا GUC** (§3 التمهيد). |
| **بيانات اصطناعية (R1)** | وفق §3: `tenants(A,B)`؛ اشتراك فعّال لكل منهما + اشتراك CANCELLED تاريخي لـ A (قانوني بعد MODEL_B: إسقاط `uk_tenant` V20260906_2 L33 والفهرس الجزئي L36–38 يقيّد الفعّال المتزامن فقط). |
| **الخطوات** | (1) معاملة تجهيز مستقلة تُثبَّت (طبقة A تحتاج بقاءً عبر HTTP)؛ (2) استدعاء المسار بشهادة A → تسجيل الاستجابة كاملة؛ (3) بشهادة B؛ (4) بلا هوية؛ (5) معاملة تنظيف مستقلة §6.4. |
| **المتوقع** | A: صف فعّال واحد لـ A فقط (والبطلان المستبعد من "الفعّال")؛ B: صف B فقط؛ بلا سياق: 401/403 قبل أي SQL. |
| **PASS/FAIL/الحجب** | PASS = تطابق تام مع سجل. FAIL = ظهور أي صف للمستأجر الآخر. `BLOCKED_PREREQUISITE` = لا بيئة تشغيل معزولة. **الحالة اليوم: `NOT_RUN`.** |
| **التراجع/التنظيف (R5)** | §6.4 صف A1: `tenant_subscriptions` → `tenants` (+ التابعات إن وُجدت)؛ إثبات COUNT=0 لكل UUID. |
| **المصادر** | SubscriptionResolutionService.java L73/L93/L110؛ V19 L38–66 (L58 FK بلا CASCADE)؛ V20260906_2 L33, L36–38؛ §3. |

### R2R-A2 — الاستحقاقات والاستخدام: لا تسرب عبر المستأجرين

| الحقل | النص |
|---|---|
| **الهدف/الافتراض** | حسابات الاستحقاق/الاستخدام تُقيَّد بـ `tenant_id = ?` صراحة — لا تسرب خطط/استهلاك بين المستأجرين. **مستوى**: تطبيق. |
| **سجل الهوية (R4)** | (1) مستخدم JWT عادي؛ (2) مستأجر الفاعل = A ثم B؛ (3) لوحة التحكم = لا ينطبق؛ (4) المستهدف = الفاعل نفسه (الخدمة تقرأ من سياق الهوية)؛ (5) القدرة = قدرات الوحدة العادية. |
| **المسار المُختبَر** | `UsageMeteringService`: قراءة الاستخدام من `usage_aggregates` بفلتر `u.tenant_id = ?` (L113–114)؛ استحقاقات الاشتراك `ts.tenant_id = ?` (L171) والقدرات (L178)؛ `EntitlementResolver.getEffectiveEntitlements` يرفض tenantId فارغًا (L192, L194/201 denied). مسار الكتابة يضبط GUC أولًا (`applyForCurrentTransaction` L59) قبل `INSERT INTO usage_events` (L63) — آلية §3. |
| **بيانات اصطناعية (R1)** | A وB باشتراكات مختلفة + سجل استخدام لكل منهما؛ جداول الاستخدام الفعلية `usage_events` (V20260830_2 L52–65: NOT NULLs `tenant_id/metric_code/quantity/idempotency_key/occurred_at/created_at`؛ `UNIQUE (tenant_id, metric_code, idempotency_key)` L63) و`usage_aggregates` (L73–86: `UNIQUE (tenant_id, metric_code, period_type, period_start)` L83) — **وليس `tenant_usage`** (تصحيح R2 الموروث). |
| **الخطوات والمتوقع** | تجهيز مستقل → استدعاء بشهادة A (استحقاقات/استخدام A فقط) → بشهادة B (B فقط) → بلا هوية (`denied`/401-403) → تنظيف مستقل. |
| **PASS/FAIL/الحجب** | PASS = لا أي عنصر من المستأجر الآخر. FAIL = تسرب أي حد/سجل. `BLOCKED_PREREQUISITE` = لا بيئة. **الحالة اليوم: `NOT_RUN`.** |
| **التراجع/التنظيف (R5)** | §6.4 صف A2: `usage_events` → `usage_aggregates` → `tenant_subscriptions` → `tenants`؛ COUNT=0 لكل UUID. |
| **المصادر** | UsageMeteringService.java L36–40, L59, L63, L85–89, L110–114, L171, L178؛ EntitlementResolver.java L112, L192, L194/201؛ V20260830_2 L52–86. |

### R2R-A3 — بوابة القدرة تحجب تغيير الخطة عن مستخدم مستأجر عادي

| الحقل | النص |
|---|---|
| **الهدف/الافتراض** | نقاط التغيير محمية بسلسلة البوابتين (§02)؛ المستأجر العادي بلا القدرة يُرفض **قبل أي SQL كتابي**. **مستوى**: تطبيق. |
| **سجل الهوية (R4)** | سيناريو الرفض: (1) مستخدم B عادي؛ (2) مستأجر الفاعل = B؛ (3) مستأجر لوحة التحكم = مهيّأ لكن ≠ B ⇒ رفض بوابة اللوحة (L45–47) أو رفض القدرة أولًا — **المصدر يُحدد من السجلات**؛ (4) المستهدف = اشتراك A؛ (5) القدرة = EXECUTIVE_MANAGE غير مملوكة. سيناريو التحكم الموجب: فاعل تنفيذي من مستأجر لوحة التحكم (عناصر 1–5 تُسجل كلها). |
| **المسار المُختبَر** | W3 (L118–131) وW4 (L133–141) وW6 (L176–183) — حراس L124/L138/L181. |
| **المتوقع** | B-عادي: 403 (مصنف المصدر) + صفر صفوف جديدة في `subscription_commands`/`provisioning_jobs`/`provisioning_job_steps` منسوبة للاشتراك الهدف؛ تنفيذي: مسموح (تصميم — راجع C3)؛ بلا هوية: 401. |
| **PASS/FAIL/الحجب** | PASS = 403/401 مصنفة + عدّادات ثابتة. FAIL = 200 لبلا قدرة أو صف كتابة من فاعل غير مصرح. `BLOCKED_PREREQUISITE` = لا بيئة. **الحالة اليوم: `NOT_RUN`.** |
| **التراجع/التنظيف (R5)** | عند PASS: إثبات عدّادات فقط. عند FAIL: تنظيف تعويضي وفق أثر الكتابة المثبت §6.4 (جدول C3) + تسجيل حادث. |
| **المصادر** | LifecycleController.java L118–131, L133–141, L176–183؛ ControlPlaneAccessGuard.java L25–47؛ ControlPlaneAccessService.java L36–52. |

### R2R-A4 — استخراج الهوية يفشل غلقًا

| الحقل | النص |
|---|---|
| **الهدف/الافتراض** | تعذر استخراج tenant_id/user_id ⇒ `authenticated=false, capabilities={}` — لا قدرات بلا هوية، ولا هوية من معاملات الطلب. **مستوى**: تطبيق. |
| **سجل الهوية (R4)** | سيناريوهات: (1) بلا رمز/رمز تالف — عناصر 1–2 غير موجودة عمدًا؛ (3) مستأجر اللوحة المهيّأ ثابت بيئةً؛ (4) لا مستهدف؛ (5) لا قدرة متوقعة. |
| **المسار** | `ControlPlaneAccessService.accessCheck` (L67–92): فشل الاستخراج → null (L74–77) ⇒ fail-closed `AccessCheckV2(false, Map.of())` (L79–80)؛ استثناء لكل قدرة ⇒ false (L88–90). |
| **المتوقع** | بلا هوية: `authenticated=false` + لا قدرة واحدة true؛ بشهادة A: `authenticated=true` + قدرات A الفعلية فقط. |
| **PASS/FAIL/الحجب** | PASS = حرفيًا كما فوق. FAIL = أي true بلا هوية. `BLOCKED_PREREQUISITE` = لا بيئة. **الحالة اليوم: `NOT_RUN`.** |
| **التراجع/التنظيف** | نقطة قراءة بلا كتابة — إثبات عدّادات الجداول الست الافتراضية قبل/بعد متطابقة. |
| **المصادر** | ControlPlaneAccessService.java L63, L67–92 (L74–77, L79–80, L88–90)؛ JwtAuthenticationFilter.java L74, L146–147. |

### R2R-C1 — شبكة اشتراكات لوحة التحكم: ENTRY محكوم بقدرة تنفيذية

| الحقل | النص |
|---|---|
| **الهدف/الافتراض** | سطح القراءة المركزي محكوم بـ EXECUTIVE_VIEW + بوابة مستأجر اللوحة؛ العبور عبر المستأجرين مقصود؛ العقد: **بلا قدرة أو من خارج مستأجر اللوحة ⇒ لا وصول**. **مستوى**: وصول لوحة تحكم. |
| **سجل الهوية (R4) لكل سيناريو** | حامل القدرة: (1) مستخدم تنفيذي؛ (2) مستأجر الفاعل = مستأجر اللوحة المهيّأ (يُثبت بمطابقة L45–47 نجاحها)؛ (3) مستأجر اللوحة = نفسه؛ (4) المستهدف = كل المستأجرين (تصميم) أو فلتر `tenantId` اختياري؛ (5) القدرة = EXECUTIVE_VIEW. بلا قدرة: العناصر (2)/(5) لا يطابقان ⇒ 403. بلا هوية: 401. |
| **المسار المُختبَر** | R3-endpoint GET `/api/v1/executive/subscriptions/v2` (ExecutiveReadController.java L71–86؛ معامل اختياري L74) — `SubscriptionGridQueryService` بفلتر `AND s.tenant_id = ?` عند التصفية (L52)؛ R2-endpoint GET `/tenants/v2` (L55–66) — قراءات عبر المستأجرين (TenantDirectoryQueryService.java L74–75)؛ R1-endpoint `/overview` (L48–51). |
| **بيانات اصطناعية (R1)** | وفق §3: معاملة تجهيز مثبتة — `tenants(A,B)` + اشتراك فعّال لكل منهما. |
| **المتوقع** | حامل القدرة: 200 بصفوف A+B (تصميم مقصود) + تصفية tenantId تعمل؛ بلا قدرة: 403 (مصنف: قدرة أو بوابة اللوحة) + صفر صفوف؛ بلا هوية: 401. |
| **PASS/FAIL/الحجب** | PASS = الثلاثي كما وصف مع تصنيف مصدر الرفض. FAIL = بلا قدرة يرى أي صف. `BLOCKED_PREREQUISITE` = لا بيئة (أو قيمة مستأجر اللوحة غير مهيأة ⇒ `SOURCE_VERIFICATION_REQUIRED` ثم حجب). **الحالة اليوم: `NOT_RUN`.** |
| **التراجع/التنظيف (R5)** | نقاط قراءة؛ تنظيف معاملة التجهيز: `tenant_subscriptions` → `tenants`؛ COUNT=0 لكل UUID. |
| **المصادر** | ExecutiveReadController.java L27, L48–51, L55–66, L71–86؛ SubscriptionGridQueryService.java L52؛ TenantDirectoryQueryService.java L74–75؛ ControlPlaneAccessGuard.java L21, L25–47. |

### R2R-C2 — عقد الفلتر الاختياري (`?::uuid IS NULL OR tenant_id = ?::uuid`)

| الحقل | النص |
|---|---|
| **الهدف/الافتراض** | قوائم اللوحة تقبل tenantId اختياريًا وتُرجع الكل عند حذفه — **دقة العقد لا العزل**؛ الحاجز = قدرة + مستأجر اللوحة. **مستوى**: وصول لوحة تحكم. |
| **سجل الهوية (R4)** | حامل EXECUTIVE_VIEW من مستأجر اللوحة (عناصر 1–5 كاملة)؛ المستهدف لكل استدعاء: بلا فلتر = الكل؛ بفلتر A؛ بفلتر B — **الفلتر قيمة لا هوية**. |
| **المسار المُختبَر** | W5 GET `/api/v1/executive/provisioning/jobs` (LifecycleController.java L143–149؛ النمط SQL `WHERE (?::uuid IS NULL OR tenant_id = ?::uuid)` **L154 مُعيد التحقق حرفيًا**) + النمط ذاته في `/subscriptions/v2` (ExecutiveReadController.java L74 + SubscriptionGridQueryService.java L52). |
| **بيانات اصطناعية (R1)** | A وB مع `provisioning_job` لكل منهما (أبوه `tenants` + `tenant_subscriptions` — V20260830_1 L60, L73–74) داخل معاملة التجهيز/التنفيذ وفق النمط المثبت في سجل التنفيذ. |
| **المتوقع** | بلا tenantId: كل الصفوف (A+B)؛ tenantId=A: A فقط؛ tenantId=B: B فقط؛ بلا هوية: 401. |
| **PASS/FAIL/الحجب** | PASS = تطابق العقد الثلاثي. FAIL = الفلتر يُرجع صفوف المستأجر الآخر عند التصفية. `BLOCKED_PREREQUISITE` = لا بيئة. **الحالة اليوم: `NOT_RUN`.** |
| **التراجع/التنظيف (R5)** | §6.4 صف C2: `provisioning_job_steps` → `provisioning_jobs` → `tenant_subscriptions` → `tenants` (بلا اعتماد على CASCADE V20260830_1 L73/L93)؛ COUNT=0 لكل UUID. |
| **المصادر** | LifecycleController.java L143–170 (L154)؛ ExecutiveReadController.java L74؛ SubscriptionGridQueryService.java L52؛ V20260830_1 L58–96. |

### R2R-C3 — كتابة لوحة التحكم: فصل هوية الفاعل عن المستأجر المستهدف + بوابة EXECUTIVE_MANAGE

| الحقل | النص |
|---|---|
| **الهدف/الافتراض** | الكتابة التنفيذية تقرأ `tenant_id` المستهدف من **صف الجدول** (لا من الفاعل ولا معاملات الطلب) وتكتب الدفتر بعمودين منفصلين: `tenant_id` (مستأجر الصف) مقابل `actor_tenant_id/actor_user_id` (هوية الفاعل). الحاجز = EXECUTIVE_MANAGE + بوابة اللوحة. **مستوى**: وصول لوحة تحكم (كتابة). |
| **سجل الهوية (R4) لكل سيناريو** | تنفيذي: (1) مستخدم تنفيذي؛ (2) مستأجر الفاعل = مستأجر اللوحة (يُكتب في `actor_tenant_id`)؛ (3) مستأجر اللوحة = نفسه؛ (4) المستهدف = مستأجر صف الاشتراك (يُكتب في `tenant_id`)؛ (5) القدرة = EXECUTIVE_MANAGE. بلا قدرة: (2)≠(3) أو (5) غائبة ⇒ 403 قبل أي كتابة. |
| **مصدر هوية الفاعل — إثبات من الكود (مُعيد التحقق)** | JWT → `claims.get("tenant_id")` (JwtAuthenticationFilter.java L74) → `details.put("user_id"/"tenant_id")` (L146–147) → `principalUuid(authentication,"tenant_id"/"user_id")` (LifecycleController.java L125–126؛ المُستخرِج L185–198 يقرأ `getDetails()` ويُرجع null عند الفشل) → وسيطا `actorTenantId/actorUserId` إلى `SubscriptionChangeService` (L152) → أعمدة `actor_tenant_id/actor_user_id` في `subscription_commands` (L341–348؛ القيم عند L348). مسار lifecycle: نفس السلسلة L73–74 ثم `commandService.execute(…, actorTenantId, actorUserId, …)` (L79). |
| **مصدر المستأجر المستهدف — إثبات من الكود** | `/changes`: `requireSubscription` يقرأ `s.tenant_id` من صف `tenant_subscriptions` بمعامل مرتبط (SubscriptionChangeService.java L416–434؛ SELECT عند L419–421) ويكتب به الدفتر (`ctx.tenantId()` — L346). `/provision`: `enqueueJob` يقرأ `SELECT tenant_id FROM tenant_subscriptions WHERE id = ?` (LifecycleController.java L200–202) ويُدخله في `provisioning_jobs` (L205–209). `/lifecycle/{command}`: `SubscriptionCommandService` يكتب `UPDATE tenant_subscriptions SET status` (L108/112/116) ودفتر `subscription_commands` (L130). **لا تُؤخذ النسبة من هوية الفاعل في أي مسار.** أعمدة الدفتر: `tenant_id UUID NOT NULL` + `actor_tenant_id UUID` + `actor_user_id UUID` منفصلة (V20260830_1 L36, L41–42؛ ونمط مماثل `subscription_change_events` V19 L71, L78–79). |
| **المسار المُختبَر** | W3 (L118–131؛ حارس L124)؛ W4 (L133–141؛ حارس L138)؛ W6 (L176–183؛ حارس L181)؛ W1 (L65–79؛ حارس L72). |
| **أثر الكتابة الفعلي (مُثبت من الكود — أساس تنظيف R5)** | W3 `/changes`: (1) إلغاء عنصر الخطة الحالي `subscription_items` (SubscriptionChangeService.java L305)؛ (2) عنصر PLAN جديد (L320 عبر `insertInitialPlanItem` L205–221)؛ (3) `UPDATE tenant_subscriptions SET plan_id/plan_version_id` (L326–327)؛ (4) صف `subscription_commands` (L341–348). **لا يكتب `subscription_change_events`.** W4: `provisioning_jobs` (L205–209) + حالات/خطوات (ProvisioningJobRunner.java L80, L124, L131; L209–213). W1: `tenant_subscriptions.status` (SubscriptionCommandService.java L108/112/116) + `subscription_commands` (L130). |
| **بيانات اصطناعية (R1)** | اشتراك A (هدف) + لقطة الحالة **قبل** الطلب (status/plan_id/plan_version_id + عناصر الخطة النشطة) — إلزامي للاستعادة (§6.4). |
| **المتوقع** | تنفيذي: تنفيذ + صف دفتر جديد بـ `tenant_id`=مستأجر الصف و`actor_tenant_id`=هوية الفاعل — العمودان مستقلان بنيويًا. بلا قدرة: 403 مصنف + عدّادات ثابتة. بلا هوية: 401 + صفر كتابة. |
| **PASS/FAIL/الحجب** | PASS = الثلاثة: حجب بلا قدرة + نسبة للمستأجر المستهدف مطابقة + فصل العمودين مثبت. FAIL = كتابة من بلا قدرة، أو نسبة لمستأجر مخالف للصف، أو امتزاج العمودين. `BLOCKED_PREREQUISITE` = لا بيئة. `BLOCKED_CLEANUP_UNPROVEN` = تعذر إثبات تنظيف أثر الكتابة كاملًا. **الحالة اليوم: `NOT_RUN`.** |
| **التراجع/التنظيف (R5)** | §6.4 صف C3 (الخطة الأكثر تعقيدًا): سجل معرفات + استعادة الحالة الملتقطة قبل الطلب + ترتيب FK صريح بلا CASCADE ولا حذف واسع. |
| **المصادر** | LifecycleController.java L28, L65–79, L118–141, L176–183, L185–198, L200–211؛ SubscriptionChangeService.java L152, L205–221, L296–348 (L305, L320, L326–327, L341–348), L416–434؛ SubscriptionCommandService.java L108–116, L130؛ ProvisioningJobRunner.java L80, L124, L131, L209–213؛ JwtAuthenticationFilter.java L74, L146–147؛ ControlPlaneAccessGuard.java L21, L25–47؛ V20260830_1 L33–48, L58–96؛ V19 L68–87. |

---

## §06 خطة التنفيذ والتنظيف (R5 — لا تُنفَّذ قبل اعتماد صريح منفصل)

### 6.1 الشروط المسبقة (بوابة العزل — كلها إلزامية قبل أول اتصال)

1. **بيئة معزولة مثبتة**: PostgreSQL 16 محلي (نمط `pg16-local/`، منفذ 5433، ربط 127.0.0.1 فقط) مبني بموافقة منفصلة — **غير موجود اليوم ⇒ حالة التنفيذ: `BLOCKED_PREREQUISITE`**.
2. **إثبات الهوية والعنوان قبل كل جلسة**: قاعدة/مضيف/منفذ مطابقة نصيًا للبيئة المعتمدة؛ لا أي عنوان خارجي.
3. **الدور التشغيلي — تحقق قراءة فقط بلا تعديل**: `SELECT rolname, rolsuper, rolcreatedb, rolcreaterole, rolbypassrls FROM pg_roles WHERE rolname='sanad';` المتوقع الأعلام الأربعة = `f` (العقد المرجعي ci.yml L172 — التزام يُتحقق منه لا يُفرض). **لا `ALTER ROLE`/`CREATE ROLE`/`GRANT`/`REVOKE` إطلاقًا**؛ أي مخالفة (علم=`t`/غياب الدور/قاعدة غير مملوكة — ci.yml L175–177) ⇒ **`BLOCKED_PREREQUISITE`** فوري ولا يُستكمل اختبار.
4. **بوابة الحارس**: أي مسار قبول تحت بروفايل `pg-acceptance` مع `PG_ACCEPTANCE_JDBC_URL` مخصص — الحارس يبطل أي fallback إلى DATABASE_URL/SPRING_DATASOURCE_URL (PgAcceptanceDatabaseGuard — ملف مُثبت البصمة في MANIFEST R2).
5. **لقطات ما قبل التنفيذ**: `pg_policies` (كامل الحقول للمخطط public)، `pg_class.relrowsecurity/relforcerowsecurity/relowner` للجداول المستهدفة، `pg_roles` لـ sanad، عدّادات صفوف كل جدول مستهدف، `flyway_schema_history` — تُحفظ وتُطابق بعد التنفيذ.
6. **سلسلة P0 (§3.2) + P1–P6 (§4.0)** — نجاحها الكامل شرط فتح أي اختبار سلوكي في طبقة B.

### 6.2 ترتيب التنفيذ (الأرخص/الأكثر قراءة أولًا)

```
0. لقطات ما قبل التنفيذ (6.1.5) + P0 + P1–P6          → قراءة صرفة؛ أي فشل ⇒ BLOCKED_PREREQUISITE
1. R2R-B5 (كتالوج: عقد الدور + FORCE)                  → قراءة صرفة
2. R2R-B4 (حقيقة الجدول الأم public.tenant_subscriptions) → قراءة داخل معاملة
3. R2R-B1 → R2R-B3 → R2R-B2 (محاولات T1…T6 معزولة)     → معاملات ROLLBACK + بيانات اصطناعية بروتوكول §3
4. R2R-A4 → R2R-A1 → R2R-A2 → R2R-A3                   → مسارات تطبيق (بلا كتابة إلا عند FAIL)
5. R2R-C1 → R2R-C2 → R2R-C3                            → لوحة التحكم (كتابة محكومة في C3/W3/W4/W1)
```

مبرر الترتيب: فشل مبكر في B5/B4 أو السلسلة P يعني فهمًا خاطئًا للبيئة ⇒ توقف قبل أي بيانات اصطناعية.

### 6.3 انضباط المعاملات (R2/R3)

- **اختبارات DB (B1/B3/B4 + محاولات B2 كلٌّ على حدة)**: معاملة مستقلة `BEGIN … ROLLBACK` لكل اختبار/**محاولة**؛ عند أي خطأ SQL: تسجيل SQLSTATE الفعلي ثم `ROLLBACK` صريح فوري — **لا استئناف معاملة فاشلة أبدًا**؛ UUIDs اصطناعية مسجلة مسبقًا في سجل التنفيذ.
- **اختبارات API (A/C)**: معاملات منفصلة: (1) تجهيز مثبت (تُسجَّل UUIDs وتُلتقط الحالة قبل التعديل)؛ (2) تنفيذ HTTP؛ (3) **معاملة تنظيف مستقلة لكل اختبار** وفق §6.4 — إلزامية حتى عند PASS.
- الحد الأدنى للصفوف: اشتراك واحد لكل مستأجر (مرجع D-18). أي FAIL يترك كتابة ⇒ حذف تعويضي بالـ UUID بترتيب FK + تسجيل حادث.

### 6.4 التنظيف وإثبات عدم البقايا (R5 — مُثبت من آثار الكتابة الفعلية للمصدر)

**آثار الكتابة المثبتة لكل مسار (قائمة فحص من المصدر — ليست افتراضًا؛ أي مسار يُثبت لاحقًا أنه يكتب جدولًا إضافيًا يُضاف أثره إلزاميًا)**:

| المسار | الجداول المكتوبة (دليل: ملف + أسطر) | ملاحظات |
|---|---|---|
| W3 `/changes` | `subscription_items` (إلغاء L305 + جديد L320 عبر L205–221)؛ `tenant_subscriptions.plan_id/plan_version_id` (L326–327)؛ `subscription_commands` (L341–348) | **لا يكتب `subscription_change_events`** |
| W4 `/provision` | `provisioning_jobs` (LifecycleController L205–209)؛ `provisioning_job_steps` + حالات (ProvisioningJobRunner L80, L124, L131, L209–213) | مهام تُنفَّذ عبر Runner — تحقق من اكتمال الخطوات وقت التنفيذ |
| W1 `/lifecycle/{command}` | `tenant_subscriptions.status` (SubscriptionCommandService L108/112/116)؛ `subscription_commands` (L130) | أثر مثبت حديثًا في R3 |
| W2 `/change-preview` | قراءة فقط (لا كتابة مثبتة من المصدر) | إن ظهرت كتابة وقت التنفيذ ⇒ توقف + `SOURCE_VERIFICATION_REQUIRED` |
| W5/R3-endpoint/… | قراءة فقط | — |
| عداد الاستخدام | `usage_events` (UsageMeteringService L63)؛ `usage_aggregates` (L85–89 upsert) | خارج مسارات C المختبرة؛ يُدخل في الإثبات العالمي |
| Outbox الفوترة | `subscription_billing_outbox` — يكتبه تدفق الفوترة وليس مسارات C المختبرة | يظهر فقط كبيانات اصطناعية B داخل معاملات تُلغى |

**قواعد التنظيف الإلزامية (لكل اختبار تغييري)**: (1) سجل معرفات كل السجلات الاصطناعية قبل التنفيذ؛ (2) لقطة الحالة قبل أي طلب يعدّل بيانات موجودة (status/plan_id/plan_version_id/عناصر الخطة) لاستعادتها؛ (3) حذف **صريح** بترتيب FK — **يُمنع الاعتماد على `ON DELETE CASCADE` حتى حيث وُجد (V20260830_1 L46/L73/L93؛ V19 L83؛ V20260829_3 L35؛ V20260830_2 L62/L82) ويُمنع أي حذف واسع غير محدد بـ UUIDs السجل**؛ (4) فصل الأساسي (`tenants`/`tenant_subscriptions`) عن التابع؛ (5) جداول Outbox/مهام: تُفحص آثارها (`subscription_billing_outbox`، `provisioning_job_steps`) ضمن إثبات الصفر؛ (6) أي أثر خارجي غير قابل للتراجع داخل القاعدة (بريد/ويب-هوك/طابور خارجي) يُرصد وقت التنفيذ ⇒ منع التشغيل + `BLOCKED_CLEANUP_UNPROVEN` إن تعذر ضبطه.

**الترتيب العام للحذف (يحترم FK، صريح بلا CASCADE)**:
`provisioning_job_steps` → `provisioning_jobs` → `subscription_commands` → `subscription_change_events` (إن وُجدت) → الأقمار السبعة (إن وُجدت) → `billing_invoices` → `usage_events` → `usage_aggregates` → `subscription_items` → `tenant_subscriptions` (بعد استعادة أعمدتها أو حذفها إن كانت اصطناعية) → `tenants`.

**جدول التنظيف لكل اختبار ثم الإثبات العالمي**: يُحتفظ بجدول R2 §6.4 كاملًا (نفس البنية: معاملات مستقلة؟/جداول بالإبترتيب/الإثبات) مع تعديلين: (أ) صف B2 يصبح "محاولة T1…T6 لكل منها ROLLBACK مستقل + COUNT فوري لكل UUID"؛ (ب) صف C3 يستعين بجدول الآثار أعلاه (يشمل أثر W1 إن استُخدم). الإثبات العالمي الختامي: ROLLBACK ناجح لكل معاملة DB (سجل الجلسة) + عدّادات صفرية لكل UUID في: `tenants`, `tenant_subscriptions`, `subscription_change_events`, `subscription_commands`, `provisioning_jobs`, `provisioning_job_steps`, `billing_invoices`, `usage_events`, `usage_aggregates`, الأقمار السبعة = 0 + لقطات `pg_policies`/`pg_class` بعد التنفيذ مطابقة قبلها + `flyway_schema_history` بلا ترحيلات جديدة + `pg_roles` لقطة مطابقة (لم يُنفَّذ `ALTER ROLE` أصلًا — 6.1.3).

### 6.5 المحظورات المطلقة أثناء التنفيذ

أي INSERT/UPDATE/DELETE خارج نصوص المصفوفة المعتمدة حرفيًا؛ أي DDL/تعديل RLS/GRANT/REVOKE/تعريف أو تعديل أدوار/`flyway clean`؛ أي اتصال بإنتاج أو Supabase/Render أو استخدام أسرار/رموز؛ أي push/merge/deploy — **ثوابت الحوكمة باقية**: `P0 SECURITY HOLD = ACTIVE` · `G1 = HOLD` · `PAYMENTS = OFF` · `NO DEPLOY` · `commercial_go_live = NOT_APPROVED`.

### 6.6 شروط التوقف الفوري

1. فشل أي شرط من 6.1 (بما فيه أي عدم تطابق في خصائص الدور أو سلسلة P0/P1–P6) ⇒ توقف + `BLOCKED_PREREQUISITE`.
2. فشل تنظيف أي اختبار ⇒ توقف + حادث موثق — لا استكمال فوق بقايا (`BLOCKED_CLEANUP_UNPROVEN`).
3. نتيجة B4 تخالف المصدر ⇒ توقف + إعادة اشتقاق (المصفوفة تفقد صلاحيتها الآنية).
4. رصد أي أثر خارجي غير قابل للضبط (6.4-6) ⇒ `BLOCKED_CLEANUP_UNPROVEN`.

---

## §07 ملخص معايير الحكم والحالة الحالية

| الحكم | الشرط |
|---|---|
| `PASS` | مطابقة فعلية للمتوقع **مع سجل تنفيذ محفوظ** — لا PASS بلا تنفيذ |
| `FAIL` | مخالفة فعلية مع دليل — تستلزم إعادة اشتقاق/معالجة قبل أي اعتماد |
| `NOT_RUN` | مصمم ولم يُنفَّذ |
| `BLOCKED_PREREQUISITE` | شرط مسبق غائب (بيئة/دور/كتالوج/تجهيز) — لا حكم سلوكي؛ مخالفة الدور تُسجَّل BLOCKED لا تُصلح |
| `BLOCKED_CLEANUP_UNPROVEN` | تنظيف غير مثبت — يمنع التشغيل |
| `SOURCE_VERIFICATION_REQUIRED` | نقطة بلا دليل مصدري كافٍ — لا تخمين ولا اختراع أسطر |
| `EXPECTED_SQLSTATE_REQUIRES_RUNTIME_CONFIRMATION` | توقع SQLSTATE مشتق من المصدر — القيمة الفعلية وقت التنفيذ حاكمة |

**الحالة الحالية لكل الخانات الاثنتي عشرة**: التصميم المصحّح جاهز للمراجعة البشرية المستقلة (**READY FOR REVIEW**) — **هذا ليس موافقة تنفيذ**؛ كل خانة `NOT_RUN`، والتنفيذ `BLOCKED_PREREQUISITE`: لا بيئة معزولة مثبتة اليوم، وبناؤها وتشغيل الاختبارات يستلزمان اعتمادًا صريحًا منفصلًا.

---

## §08 فهرس الأدلة المصدرية (مُعيد التحقق قراءةً فقط بتاريخ 2026-10-28)

| الملف (مسار نسبي من جذر المستودع) | الأسطر المستشهَدة في R3 | التحقق |
|---|---|---|
| `apps/sanad-platform/src/main/java/com/sanad/platform/subscription/api/LifecycleController.java` | 28, 65–79, 105–111, 118–131, 133–141, 143–170 (154), 176–183, 185–198, 200–211 | قراءة مباشرة اليوم + بصمة مطابقة لـ MANIFEST R2 |
| `…/subscription/api/ExecutiveReadController.java` | 27, 48–51, 55–66, 71–86, 89–94, 105–110 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/security/authorization/ControlPlaneAccessGuard.java` | 21, 25–47, 50–57, 60–86 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/subscription/rbac/ControlPlaneAccessService.java` | 22–31, 36–52, 63, 67–92 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/security/filter/JwtAuthenticationFilter.java` | 74, 146–150 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/subscription/change/SubscriptionChangeService.java` | 152, 205–221, 296–348, 416–434 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/subscription/lifecycle/SubscriptionCommandService.java` | 108–116, 130 | **استشهاد جديد في R3** — بصمته في 05_VALIDATION_REPORT |
| `…/subscription/provisioning/ProvisioningJobRunner.java` | 80, 124, 131, 209–213 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/subscription/usage/UsageMeteringService.java` | 36–40, 59, 63, 85–89, 110–114, 171, 178 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/subscription/lifecycle/SubscriptionResolutionService.java` | 73, 93, 110 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/module/entitlement/EntitlementResolver.java` | 112, 192, 194/201 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/subscription/read/SubscriptionGridQueryService.java` | 52, 76–101 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/subscription/read/TenantDirectoryQueryService.java` | 74–75 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/security/rls/TenantRlsTransactionContext.java` | 28–30, 51, 67–74, 84–85, 87–91, 98, 106 | قراءة مباشرة اليوم + بصمة مطابقة |
| `…/security/rls/TenantRlsConnectionHandler.java` | 12–19, 23–25, 32–57, 59–60 | قراءة مباشرة اليوم + بصمة مطابقة |
| `apps/sanad-platform/src/test/java/com/sanad/platform/config/PgAcceptanceDatabaseGuard.java` | (بوابة pg-acceptance — §6.1.4) | بصمة مطابقة لـ MANIFEST R2 |
| `.github/workflows/ci.yml` | 160–177 (العقد L172؛ الملكية L175–177) | قراءة مباشرة اليوم + بصمة مطابقة |
| `db/migration/V1__create_tenants_table.sql` | 21–30 | **استشهاد جديد في R3** — بصمته في 05_VALIDATION_REPORT |
| `db/migration/V16__extend_platform_identity_and_tenants.sql` | 5 | **استشهاد جديد في R3** — بصمته في 05_VALIDATION_REPORT |
| `db/migration/V19__create_saas_administration.sql` | 38–66 (57, 58), 68–87 (71, 78–79, 83, 84), 89–112 | قراءة مباشرة اليوم + بصمة مطابقة |
| `db/migration/V20260815_20__tenant_domains_and_billing_state.sql` | 25 | بصمة مطابقة لـ MANIFEST R2 |
| `db/migration/V20260829_3__scp_subscription_items.sql` | 18–45 | قراءة مباشرة اليوم + بصمة مطابقة |
| `db/migration/V20260830_1__scp_lifecycle_and_provisioning.sql` | 33–48 (36, 41–42, 46, 47), 58–96 (60, 73, 74, 83, 93) | قراءة مباشرة اليوم + بصمة مطابقة |
| `db/migration/V20260830_2__scp_usage_metering_and_rbac.sql` | 52–65, 73–86 | **استشهاد جديد في R3** — بصمته في 05_VALIDATION_REPORT |
| `db/migration/V20260906_2__scp_subscription_multiplicity_model_b.sql` | 25–27, 33, 36–38 | قراءة مباشرة اليوم + بصمة مطابقة |
| `db/migration/V20260912_4__r0c13_subscription_billing_foundation.sql` | 13–30, 34–66, 70–106, 108–132, 134–164, 168–192, 194–243, 248–295 | قراءة مباشرة اليوم + بصمة مطابقة |
