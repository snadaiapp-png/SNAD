# APR-2R — المرحلة الأولى: الأدلة الأولية (只读取证 / Read-Only Forensics)

**التقرير**: SNAD-APR2R-TEST-MATRIX-2026-10-28
**التاريخ**: 2026-10-28 (Asia/Riyadh)
**طبيعة المهمة**: استخراج أدلة للقراءة فقط — صفر اتصال بقاعدة بيانات، صفر SQL، صفر تعديل على الملفات الأصلية.
**الحالة الختامية للمصفوفة**: READY FOR APPROVAL (للمراجعة) — التنفيذ محجوز حتى بناء بيئة معزولة مثبتة.

---

## §1. نتيجة التحقق من وجود المُشار إليها (Existence Check)

قبل بدء الاستخراج، تحقّقنا من الوجود الفعلي للمرجعيات التي افترضتها سلسلة التوجيهات:

| المرجعية المفترضة | نتيجة الفحص الفعلي | الطريقة |
|---|---|---|
| "تقرير APR-2 الحالي وأدلته" | **غير موجود** | بحث شامل `**/*APR*` على كامل `/home/z/my-project` → صفر نتائج |
| مصفوفة اختبارات سابقة تحتوي `R2R-A1/B1/C1` | **غير موجودة** | grep نصي شامل على كامل مساحة العمل → صفر تطابقات |
| بيئة الاختبار المحلية `pg16-local/` | **غير موجودة** | فحص دليل مباشر → DOES NOT EXIST |
| تقارير 2026-10-27 السابقة (DB-VERIFY / TESTDB-SCAN / AUDIT-R3) | **غير موجودة** كأدلة في `download/` الحالي | فحص دليل مباشر |
| ترحيل `V20260815_22` | **غير موجود في شجرة العمل** — لكن **موجود في تاريخ git وحُذف عمدًا** (انظر §5) | `git log --all` + `git show` |

**القرار الإجرائي**: لا يوجد "تقرير APR-2 حالي" للاحتفاظ به ولا بيئة مبنية لتوثيق نسخها — لذلك أُنتج هذا التقرير **كأول مخرج فعلي منفَّذ لتوجيه APR-2R**، مع تعريف كل معرّف اختبار كـ **مشتق من المصدر (DERIVED)** وليس مستعادًا من مصفوفة مفقودة. لا تدّعي المصفوفة في هذا التقرير أنها "استعادة" لنص سابق.

## §2. حالة المستودع (Git Forensics — 只读)

```
HEAD:    c43a70a5603bdb5a63a193f66de5e83b29ecc454   ✓ يطابق خط الأساس المعتمد
Branch:  review/unified-control-plane-revision-c-reconstructed   ✓ يطابق
Status:  4096 ملفًا يظهر "M" في git status --porcelain
```

**ملاحظة حول الـ 4096**: أول ملف معدَّل في القائمة هو `.gitattributes`، والنمط متسق مع أثر تطبيع نهايات الأسطر (line-ending normalization) على ملفات لم تُغيَّر محتواها منطقيًا. **لم تُراجَع diffs هذه الملفات في هذه المهمة** (خارج نطاق取证 الحالي)؛ يُسجَّل الرقم كحقيقة ملاحظة فقط، ولا يُستخلص منه أي حكم.

## §3. تعريف الجدول tenant_subscriptions — التطور عبر الترحيلات

### 3.1 الإنشاء الأصلي — `V19__create_saas_administration.sql` L38–66

```sql
CREATE TABLE tenant_subscriptions (
    id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    plan_id UUID NOT NULL,
    pending_plan_id UUID,
    status VARCHAR(24) NOT NULL,
    billing_cycle VARCHAR(16) NOT NULL,
    pending_billing_cycle VARCHAR(16),
    seat_quantity INTEGER NOT NULL,
    credit_balance_minor BIGINT NOT NULL,
    started_at TIMESTAMPTZ NOT NULL,
    trial_ends_at TIMESTAMPTZ,
    current_period_start TIMESTAMPTZ NOT NULL,
    current_period_end TIMESTAMPTZ NOT NULL,
    cancel_at_period_end BOOLEAN NOT NULL,
    cancelled_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL,
    CONSTRAINT pk_tenant_subscriptions PRIMARY KEY (id),
    CONSTRAINT uk_tenant_subscriptions_tenant UNIQUE (tenant_id),
    CONSTRAINT fk_tenant_subscriptions_tenant FOREIGN KEY (tenant_id) REFERENCES tenants (id),
    CONSTRAINT fk_tenant_subscriptions_plan FOREIGN KEY (plan_id) REFERENCES saas_plans (id),
    CONSTRAINT fk_tenant_subscriptions_pending_plan FOREIGN KEY (pending_plan_id) REFERENCES saas_plans (id),
    CONSTRAINT ck_tenant_subscriptions_status CHECK (status IN ('TRIALING','ACTIVE','PAST_DUE','SUSPENDED','CANCELLED')),
    CONSTRAINT ck_tenant_subscriptions_cycle CHECK (billing_cycle IN ('MONTHLY','ANNUAL')),
    CONSTRAINT ck_tenant_subscriptions_pending_cycle CHECK (pending_billing_cycle IS NULL OR pending_billing_cycle IN ('MONTHLY','ANNUAL')),
    CONSTRAINT ck_tenant_subscriptions_seats CHECK (seat_quantity > 0),
    CONSTRAINT ck_tenant_subscriptions_credit CHECK (credit_balance_minor >= 0)
);
```

### 3.2 الجداول المرتبطة (علاقات FK نحو/من الجدول الأم)

| الجدول | العلاقة | المصدر |
|---|---|---|
| `subscription_change_events` | FK `subscription_id → tenant_subscriptions(id) ON DELETE CASCADE` + `tenant_id → tenants(id)` | V19 L68–87 |
| `billing_invoices` | FK `subscription_id → tenant_subscriptions(id)` + `tenant_id → tenants(id)` | V19 L89–117 |
| `scp_subscription_items` | FK `subscription_id → tenant_subscriptions(id) ON DELETE CASCADE` | V20260829_3 L35 |
| `subscription_commands` | FK `subscription_id → tenant_subscriptions(id) ON DELETE CASCADE` + `tenant_id → tenants(id)` | V20260830_1 L33–48 |
| `provisioning_jobs` (+steps) | FK `subscription_id → tenant_subscriptions(id) ON DELETE CASCADE` | V20260830_1 L58+ |
| 7 جداول `subscription_billing_*` | FK مركّب `(tenant_id, subscription_id) → tenant_subscriptions(tenant_id, id)` | V20260912_4 L54, L94, L125 |

### 3.3 التعديلات اللاحقة (زمنيًا)

| الترحيل | التغيير | الأسطر |
|---|---|---|
| `V20260815_20` | إضافة `billing_state VARCHAR(20) NOT NULL DEFAULT 'CURRENT'` + CHECK بحالات (TRIALING/CURRENT/PAST_DUE/SUSPENDED/CANCELLED) + index `(tenant_id, billing_state)` | L73–94 |
| `V20260829_2` | إضافة `plan_version_id` (nullable، FK شرطي نحو saas_plan_versions) + index | L88–107 |
| `V20260830_1` | توسيع `ck_tenant_subscriptions_status` إضافيًا: + DRAFT, PENDING_ACTIVATION, PENDING_PAYMENT, TRIAL, GRACE_PERIOD, PAUSED, EXPIRED, TERMINATED | L20–28 |
| `V20260906_2` (MODEL_B) | **إسقاط** `uk_tenant_subscriptions_tenant`؛ استبداله بـ partial unique index `uk_tenant_subscriptions_effective ON (tenant_id) WHERE status NOT IN ('CANCELLED','EXPIRED','TERMINATED')` + index `(tenant_id, status)` | L33–42 |
| `V20260912_4` | إضافة `uk_tenant_subscriptions_tenant_id ON (tenant_id, id)` (تمكين FK المركّب للأقمار) | L8–9 |

## §4. حالة RLS — لامتماثل موثّق بمصادر دقيقة

### 4.1 الأقمار السبعة subscription_billing_* — RLS مفعل ومفروض (V20260912_4 L248–295)

لكل جدول من: `provider_customers`, `payment_attempts`, `provider_events`, `finance_links`, `outbox`, `reconciliation_runs`, `reconciliation_items`:

```sql
ALTER TABLE <satellite> ENABLE ROW LEVEL SECURITY;
ALTER TABLE <satellite> FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation ON <satellite>;
CREATE POLICY tenant_isolation ON <satellite> FOR ALL
    USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
```

الأسطر: L248–253 (provider_customers)، L255–260 (payment_attempts)، L262–267 (provider_events)، L269–274 (finance_links)، L276–281 (outbox)، L283–288 (reconciliation_runs)، L290–295 (reconciliation_items). التعليق المرافق L247: "Fail-closed FORCE RLS on every R0C13 tenant-owned table."

### 4.2 الجدول الأم tenant_subscriptions — صفر عبارات RLS

- فحص شامل (grep غير حساس لحالة الأحرف) لكل ملفات الترحيل عن `tenant_subscriptions`: **لا يوجد أي سطر** `ENABLE ROW LEVEL SECURITY` / `FORCE ROW LEVEL SECURITY` / `CREATE POLICY` يستهدفه.
- **إقرار نصي داخل المستودع** — `V20260906_2` L25–27:
  > "NO RLS statement is touched (tenant_subscriptions is not an RLS-enforced table in this repository; module tables keep their RLS untouched)."
- **إحالة إلى ترحيل RLS غير موجود** — `V20260815_20` L25:
  > "PostgreSQL-specific RLS policies are added in V20260815_22."

### 4.3 الحقيقة الجوهرية: V20260815_22 لم يكن "مفقودًا" — بل أُسقط بقرار حوكمي مسجّل

اكتشاف التاريخ (`git log --all`):

```
0a3e88c5b fix(governance): drop lifecycle RLS migration, isolate governed-systems overviews
   D  apps/sanad-platform/src/main/resources/db/vendor/postgresql/V20260815_22__enable_lifecycle_rls.sql   (76 سطرًا)
   D  apps/sanad-platform/src/test/resources/db/vendor/h2/V20260815_22__enable_lifecycle_rls.sql           (15 سطرًا)
   A  .../GovernedSystemsOverviewService.java (+121)
```

محتوى الترحيل المسقوط (مستعاد للقراءة فقط من `0a3e88c5b^`) يثبت ثلاث حقائق:

1. **كان يستهدف tenant_subscriptions صراحةً** ضمن مصفوفة: organizations, organization_memberships, users, roles, role_capabilities, user_role_assignments, **tenant_subscriptions**, billing_invoices, subscription_change_events — بسياسة `tenant_isolation USING (tenant_id = current_setting('app.tenant_id', true)::uuid)` بوضع **ENABLE (ليس FORCE)**.
2. **ترويسته اعترفت بالفجوة قبل الإسقاط**: "the tenant-owned lifecycle base tables … rely solely on application-layer WHERE tenant_id filtering. This migration enables PostgreSQL Row-Level Security as a second line of defense."
3. **الإسقاط كان مقصودًا** ضمن كومِت حوكمي بنفس التاريخ (2026-08-15) نقل مسؤولية عزل "الأنظمة المحكومة" إلى طبقة التطبيق (`GovernedSystemsOverviewService`).

**التصنيف الإلزامي**: غياب RLS على `tenant_subscriptions` = **قرار تصميمي مسجّل في تاريخ المستودع**، وليس سهوًا. المصفوفة (المستوى B) تتعامل معه كحقيقة مستمدة تُختبر وجودها في البيئة (R2R-B4)، ولا تقدّمه كادعاء "ثغرة قابلة للاستغلال" — انظر `03_REASONING_BOUNDARIES.md` §2.

## §5. مسارات القراءة/الكتابة في طبقة التطبيق

### 5.1 آلية سياق المستخدم `app.tenant_id` (GUC)

| المكوّن | الآلية | المصدر |
|---|---|---|
| `TenantRlsConnectionHandler` | `stmt.execute("SET LOCAL app.tenant_id = '" + tenantId + "'")` قبل أول عبارة | security/rls/TenantRlsConnectionHandler.java L77 |
| `TenantRlsTransactionContext` | `SELECT set_config('app.tenant_id', ?, true)` داخل معاملة Spring؛ يفشل غلقًا خارج المعاملة (L84) | security/rls/TenantRlsTransactionContext.java L91, L84 |
| `TenantRlsDataSourcePostProcessor` | وكيل DataSource يضمن التطبيق قبل أول استعلام | security/rls/TenantRlsDataSourcePostProcessor.java L20 |

**ملاحظة نطاق**: هذه الآلية موثّقة الاستخدام في وحدات CRM/HR/PerfTest وجداولها؛ **وحدة الاشتراكات (subscription/*) لا تستدعيها** في مساراتها — عزلها التطبيقي يتم بمعاملات SQL مرتبطة (`WHERE tenant_id = ?`) وليس بـ GUC. لهذا لا يجوز افتراض أن `app.tenant_id` يثبت أي عزل على الجدول الأم (انظر الحدود §3).

### 5.2 المسار المواجه للمستأجر (Tier A — app-layer filtering)

| المسار | الفلترة | المصدر |
|---|---|---|
| حل الاشتراك الفعّالة | `FROM tenant_subscriptions WHERE tenant_id = ? AND <EFFECTIVE_PREDICATE>`؛ التاريخ: `WHERE tenant_id = ? ORDER BY created_at DESC` | subscription/lifecycle/SubscriptionResolutionService.java L73, L93, L110 |
| الاستخدام | `WHERE u.tenant_id = ? AND u.period_type = 'MONTHLY'`؛ `WHERE ts.tenant_id = ? AND ts.status IN ('ACTIVE','TRIALING','TRIAL')`؛ `WHERE ts.tenant_id = ? AND pel.capability_code IN (...)` | subscription/usage/UsageMeteringService.java L114, L171, L178 |
| الاستحقاقات | `EntitlementResolver.getEffectiveEntitlements(tenantId, moduleCode)` — tenantId معامل صريح مطلوب غير فارغ | module/entitlement/EntitlementResolver.java L191–201 |
| تسوية الفواتير/الاستبيان | عبارات JDBC بكلها `WHERE tenant_id = ?` | billing/application/BillingSettlementService.java L223–352; BillingReconciliationService.java L51–244 |

### 5.3 مسار لوحة التحكم المركزية (Tier C — intentional cross-tenant)

| المسار | البوابة | السلوك | المصدر |
|---|---|---|---|
| GET `/provisioning/jobs` | `@RequireCapability("EXECUTIVE_VIEW")` + `accessGuard.require` | فلتر اختياري: `WHERE (?::uuid IS NULL OR tenant_id = ?::uuid)` — يُرجع الكل عند حذف المعامل | subscription/api/LifecycleController.java L143–170 |
| POST `/subscriptions/{id}/changes` | `@RequireCapability("EXECUTIVE_MANAGE")` | الكتابة تُنسب لـ tenant_id **المستخرج من صف الجدول**: `SELECT tenant_id FROM tenant_subscriptions WHERE id = ?` | LifecycleController.java L118–131 + L200–211 |
| POST `/subscriptions/{id}/provision`, `/retry` | `@RequireCapability("EXECUTIVE_MANAGE")` | نفس النمط عبر enqueueJob | LifecycleController.java L133–141, L176–183 |
| شبكة الاشتراكات (Executive/SCP) | قدرات EXECUTIVE_VIEW / subscription.read | فلتر اختياري `AND s.tenant_id = ?` | subscription/read/SubscriptionGridQueryService.java L52 |
| دليل المستأجرين | قدرات القراءة التنفيذية | استعلامات عبر جميع المستأجرين (`SELECT COUNT(*) FROM tenant_subscriptions s WHERE s.tenant_id = t.id`) | subscription/read/TenantDirectoryQueryService.java L74–75 |
| تقييم قدرات التحكم | استخراج هوية fail-closed: `tenantId == null || userId == null → AccessCheckV2(false, {})` — "never taken from request parameters, never defaulted, never fails open" | subscription/rbac/ControlPlaneAccessService.java L22–31, L66–93 |

### 5.4 سجل القدرات المعتمدة للوحة التحكم

`ControlPlaneAccessService.CONTROL_PLANE_CAPABILITIES` (L36–52): EXECUTIVE_VIEW, EXECUTIVE_MANAGE, subscription.read/create/change_plan/cancel/suspend, catalog.*, application.*, plan.*, pricing.*, entitlement.*, usage.read, billing.*, provisioning.*, audit.read.

## §6. بوابة قاعدة البيانات وعقد الدور

### 6.1 `PgAcceptanceDatabaseGuard.java` (بروفايل `pg-acceptance` فقط)

المسار: `apps/sanad-platform/src/test/java/com/sanad/platform/config/PgAcceptanceDatabaseGuard.java`

| الحماية | التفصيل | الأسطر |
|---|---|---|
| إلزام URL مخصص | `PG_ACCEPTANCE_JDBC_URL` فارغ → إجهاض؛ **يحظر fallback إلى `DATABASE_URL` / `SPRING_DATASOURCE_URL`** (بيانات الإنتاج) | L96–111 |
| مضيفات محظورة | `snad-prod`, `render-db.internal` | L66–69, L130–139 |
| مرجع إنتاج دقيق | `tkbrvupemreqabwzdpyq` (مشروع Supabase الإنتاجي) — أي احتواء في URL → إجهاض | L80–82, L144–154 |
| أسماء قواعد محظورة | `prod`, `snad-prod`, `production` | L85–87, L156–166 |
| إخفاء كلمة المرور في السجلات | `mask()` يستبدل `password=***` | L211–213 |

**لا يوجد أي مسار fallback خارجي** — الفشل دائمًا إجهاض بدء التشغيل (fail-fast). المكون يُنشأ فقط تحت بروفايل `pg-acceptance` وليس تحت `prod` (L48–50).

### 6.2 عقد الدور في CI — `.github/workflows/ci.yml`

```sql
-- L168–172
IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sanad') THEN
  CREATE ROLE sanad WITH LOGIN PASSWORD 'sanad_pass';
...
ALTER ROLE sanad NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;
```
- L174–177: قاعدة البيانات `sanad` مملوكة لـ `sanad` — وبما أن FORCE RLS مفروض على الأقمار، **يخضع المالك نفسه للسياسة** (تعليق L34: "Since `sanad` owns the tables it creates, FORCE RLS applies to it").
- L102–104: `SPRING_DATASOURCE_URL: jdbc:postgresql://127.0.0.1:5432/sanad?prepareThreshold=0` — محلي فقط.

### 6.3 حالة بيئة التنفيذ المحلية

- `pg16-local/` غير موجود → لا يوجد مثيل PG16 محلي للتحقق السلوكي الآن.
- أي تنفيذ مستقبلي للمصفوفة يتطلب: بناء البيئة + إثبات العزل (هوية/عنوان/لا fallback) + دور `sanad` وفق عقد L172 — كلها خارج نطاق APR-2R وتخضع لموافقة منفصلة.

## §7. أثر تتبع سريع (Fingerprint) للملفات المصدرية المُستشهَدة

تُحسب SHA-256 لكل ملف مصدر مُستشهَد وتُدرج في `MANIFEST.sha256` مع مخرجات هذا التقرير، لتثبيت النسخة المدققة من الأدلة عند HEAD `c43a70a5`.
