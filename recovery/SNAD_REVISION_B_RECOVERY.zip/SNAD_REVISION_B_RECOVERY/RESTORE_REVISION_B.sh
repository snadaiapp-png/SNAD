#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 /path/to/SNAD" >&2
  exit 2
fi
REPO="$1"
ROOT="$(cd "$(dirname "$0")" && pwd)"
BASE="8d0d49c7bdd3ad3a886a23cffc1e735e61998712"
cd "$REPO"
git cat-file -e "${BASE}^{commit}"
git switch --detach "$BASE"
BRANCH="docs/unified-control-plane-plan-recovery-r2"
if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  git branch -D "$BRANCH"
fi
git switch -c "$BRANCH"
while read -r sha path; do
  mkdir -p "$(dirname "$path")"
  cp "$ROOT/$path" "$REPO/$path"
done < "$ROOT/SHA256SUMS"
cd "$ROOT"
sha256sum -c SHA256SUMS
cd "$REPO"
echo "RECOVERY_BRANCH=$BRANCH"
echo "BASE_SHA=$BASE"
git status --short
